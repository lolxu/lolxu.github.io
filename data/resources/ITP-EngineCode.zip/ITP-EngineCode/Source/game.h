#pragma once
#include "Graphics.h"
#include "Lights.h"

class Shader;

class Game
{
public:
	Game();
	~Game();

	void Init(HWND hWnd, float width, float height);
	void Shutdown();
	void Update(float deltaTime);
	void RenderFrame();

	void OnKeyDown(uint32_t key);
	void OnKeyUp(uint32_t key);
	bool IsKeyHeld(uint32_t key) const;

	// Public lighting functions
	Lights::PointLightData* AllocateLight();
	void FreeLight(Lights::PointLightData* pLight);
	void SetAmbientLight(const Vector3& color);
	const Vector3& GetAmbientLight() const;

	class AssetManager* GetAssetManager();
	class Camera* GetCamera() { return m_camera; }
	class Physics* GetPhysics() { return m_physics; }

	struct GaussianConstants
	{
		Vector2 c_textureSize;
		bool c_isHorizontal;
		float padding;
	};

private:
	std::unordered_map<uint32_t, bool> m_keyIsHeld;
	Graphics pGraphics;

	// Holding D3D11Buffer (Vertex buffer)
	ID3D11Buffer* m_d3dvertexBuffer;

	// Camera Pointer
	class Camera* m_camera;

	bool LoadLevel(const WCHAR* fileName);

	// Lighting
	Lights::LightingConstants m_lightingConstants;
	ID3D11Buffer* m_lightingBuffer;

	// Asset Manager
	class AssetManager* m_assetManager;

	// Vector of render objects
	std::vector<class RenderObj*> m_renderObjects;

	// Temp mesh for triangle
	class Mesh* triagMesh;

	// Physics Instance
	class Physics* m_physics;

	// Off-screen Textures
	class Texture* m_offscreenTexture;
	class Texture* m_halfSizedTexture;
	class Texture* m_quarterSizedTexture_A;
	class Texture* m_quarterSizedTexture_B;

	// Render targets
	ID3D11RenderTargetView* m_offScreenRenderTarget;
	ID3D11RenderTargetView* m_halfSizedTarget;
	ID3D11RenderTargetView* m_quarterSizedTarget_A;
	ID3D11RenderTargetView* m_quarterSizedTarget_B;

	// Vertex buffer for full-screen quad
	class VertexBuffer* m_quadBuffer;

	// For blur
	GaussianConstants m_gaussianConstants;
	ID3D11Buffer* m_gaussianBuffer;

	// For blend states
	ID3D11BlendState* m_opaqueBlend;
	ID3D11BlendState* m_additiveBlend;
};