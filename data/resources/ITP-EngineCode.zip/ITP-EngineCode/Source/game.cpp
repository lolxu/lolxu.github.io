#include "stdafx.h"
#include "Game.h"
#include "engineMath.h"
#include "Graphics.h"
#include "Shader.h"
#include "stringUtil.h"
#include "rapidjson\include\rapidjson\rapidjson.h"
#include "rapidjson\include\rapidjson\document.h"
#include <fstream>
#include <sstream>

#include "VertexFormat.h"
#include "VertexBuffer.h"
#include "RenderObj.h"
#include "Camera.h"
#include "RenderCube.h"
#include "texture.h"
#include "Material.h"
#include "assetManager.h"
#include "mesh.h"
#include "jsonUtil.h"
#include "SkinnedObj.h"

#include "Components\PointLight.h"
#include "Components\Character.h"
#include <Components\player.h>
#include <Components\followCam.h>
#include "Physics.h"
#include "CollisionBox.h"
#include "Profiler.h"
#include "JobManager.h"
#include "Job.h"
#include "AnimJob.h"
#include "Components\SimpleRotate.h"



float g_rotationAngle = 1.0f;

Game::Game()
{
	m_camera = nullptr;
	m_d3dvertexBuffer = nullptr;
	m_lightingBuffer = nullptr;
}

Game::~Game()
{
}

void Game::Init(HWND hWnd, float width, float height)
{
	pGraphics.InitD3D(hWnd, width, height);

	{
		// Creating Asset Manager 
		m_assetManager = new AssetManager();
	}


	// Making a vertex array for all vertices on the triangle
	/*VertexPosColor vert[] =
	{
		{ Vector3(0.0f, 0.5f, 0.0f), Graphics::Color4(1.0f, 0.0f, 0.0f, 1.0f) },
		{ Vector3(0.45f, -0.5f, 0.0f), Graphics::Color4(0.0f, 1.0f, 0.0f, 1.0f) },
		{ Vector3(-0.45f, -0.5f, 0.0f), Graphics::Color4(0.0f, 0.0f, 1.0f, 1.0f) }
	};*/
	// Making the index array for indexed drawing
	/*uint16_t indices[] = { 0, 1, 2 };*/

	{
		// Loading the simple hlsl shader - MATCHING THE HLSL SEMANTICS 
		D3D11_INPUT_ELEMENT_DESC inputElem[] =
		{
			{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(VertexPosColor, pos),
			D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "COLOR", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, offsetof(VertexPosColor, color),
			D3D11_INPUT_PER_VERTEX_DATA, 0 }
		};
		Shader* meshShader = new Shader();
		meshShader->Load(L"Shaders/Mesh.hlsl", inputElem, ARRAY_SIZE(inputElem));
		m_assetManager->SetShader(L"Mesh", meshShader);
	}

	{
		// Loading the texture, normals, and basicMesh shader -------------------------

		D3D11_INPUT_ELEMENT_DESC inputElem[] =
		{
			{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(VertexPosNormalColorUV, pos), D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "NORMAL", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(VertexPosNormalColorUV, normal), D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "COLOR", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, offsetof(VertexPosNormalColorUV, color), D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, offsetof(VertexPosNormalColorUV, textureCoord), D3D11_INPUT_PER_VERTEX_DATA, 0}
		};
		Shader* basicMeshShader = new Shader();
		basicMeshShader->Load(L"Shaders/BasicMesh.hlsl", inputElem, ARRAY_SIZE(inputElem));
		m_assetManager->SetShader(L"BasicMesh", basicMeshShader);
	}

	{
		// Loading the Phong lighting shader
		D3D11_INPUT_ELEMENT_DESC inputElem[] =
		{
			{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(VertexPosNormalUV, pos), D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "NORMAL", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(VertexPosNormalUV, normal), D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, offsetof(VertexPosNormalUV, textureCoord), D3D11_INPUT_PER_VERTEX_DATA, 0}
		};
		Shader* phongShader = new Shader();
		phongShader->Load(L"Shaders/Phong.hlsl", inputElem, ARRAY_SIZE(inputElem));
		m_assetManager->SetShader(L"Phong", phongShader);
	}

	{
		// Loading the unlit shader
		D3D11_INPUT_ELEMENT_DESC inputElem[] =
		{
			{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(VertexPosNormalUV, pos), D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "NORMAL", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(VertexPosNormalUV, normal), D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, offsetof(VertexPosNormalUV, textureCoord), D3D11_INPUT_PER_VERTEX_DATA, 0}
		};
		Shader* unlitShader = new Shader();
		unlitShader->Load(L"Shaders/Unlit.hlsl", inputElem, ARRAY_SIZE(inputElem));
		m_assetManager->SetShader(L"Unlit", unlitShader);
	}

	{
		// Loading the Skinned Shader for Animations
		D3D11_INPUT_ELEMENT_DESC inputElem[] =
		{
			{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(SkinnedVertexFormat, pos), D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "NORMAL", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(SkinnedVertexFormat, normal), D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "BONES", 0, DXGI_FORMAT_R8G8B8A8_UINT, 0, offsetof(SkinnedVertexFormat, boneIndices), D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "WEIGHTS", 0, DXGI_FORMAT_R8G8B8A8_UNORM, 0, offsetof(SkinnedVertexFormat, boneWeights), D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, offsetof(SkinnedVertexFormat, textureCoord), D3D11_INPUT_PER_VERTEX_DATA, 0}
		};
		Shader* skinnedShader = new Shader();
		skinnedShader->Load(L"Shaders/Skinned.hlsl", inputElem, ARRAY_SIZE(inputElem));
		m_assetManager->SetShader(L"Skinned", skinnedShader);
	}

	{
		// Loading the Normal Map Shader
		D3D11_INPUT_ELEMENT_DESC inputElem[] =
		{
			{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(NormalMapVertexFormat, pos), D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "NORMAL", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(NormalMapVertexFormat, normal), D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "TANGENT", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(NormalMapVertexFormat, tangent), D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, offsetof(NormalMapVertexFormat, textureCoord), D3D11_INPUT_PER_VERTEX_DATA, 0 }
		};
		Shader* normalShader = new Shader();
		normalShader->Load(L"Shaders/Normal.hlsl", inputElem, ARRAY_SIZE(inputElem));
		m_assetManager->SetShader(L"Normal", normalShader);
	}

	{
		// Loading Copy shader (for full-screen pass)
		D3D11_INPUT_ELEMENT_DESC inputElem[] =
		{
			{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(CopyVertexFormat, pos), D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, offsetof(CopyVertexFormat, textureCoord), D3D11_INPUT_PER_VERTEX_DATA, 0 }
		};
		Shader* copyShader = new Shader();
		copyShader->Load(L"Shaders/Copy.hlsl", inputElem, ARRAY_SIZE(inputElem));
		m_assetManager->SetShader(L"Copy", copyShader);

		// Creating a vertex buffer for full-screen quad
		CopyVertexFormat vert[] =
		{
			{ Vector3(-1.0f, -1.0f, 0.0f), Vector2(0.0f, 1.0f) },
			{ Vector3(1.0f, -1.0f, 0.0f), Vector2(1.0f, 1.0f) },
			{ Vector3(1.0f, 1.0f, 0.0f), Vector2(1.0f, 0.0f) },
			{ Vector3(-1.0f, 1.0f, 0.0f), Vector2(0.0f, 0.0f) }
		};

		// Making indices (2 triangles)
		uint16_t indices[] = { 0, 1, 2, 0, 2, 3 };

		m_quadBuffer = new VertexBuffer(vert, ARRAY_SIZE(vert), sizeof(vert[0]), indices, ARRAY_SIZE(indices), sizeof(indices[0]));
	}

	{
		// Loading Bloom Mask shader
		D3D11_INPUT_ELEMENT_DESC inputElem[] =
		{
			{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(CopyVertexFormat, pos), D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, offsetof(CopyVertexFormat, textureCoord), D3D11_INPUT_PER_VERTEX_DATA, 0 }
		};
		Shader* bloomMaskShader = new Shader();
		bloomMaskShader->Load(L"Shaders/BloomMask.hlsl", inputElem, ARRAY_SIZE(inputElem));
		m_assetManager->SetShader(L"BloomMask", bloomMaskShader);
	}

	{
		// Loading Blur shader
		D3D11_INPUT_ELEMENT_DESC inputElem[] =
		{
			{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(CopyVertexFormat, pos), D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, offsetof(CopyVertexFormat, textureCoord), D3D11_INPUT_PER_VERTEX_DATA, 0 }
		};
		Shader* blurShader = new Shader();
		blurShader->Load(L"Shaders/Blur.hlsl", inputElem, ARRAY_SIZE(inputElem));
		m_assetManager->SetShader(L"Blur", blurShader);
	}

	{
		// CREATING MATERIAL ------------------------------------------------

		/*Material* triagMaterial = m_assetManager->LoadMaterial(L"TriagMat");
		triagMaterial->SetShader(m_assetManager->GetShader(L"Mesh"));*/

		//Material* cubeMaterial = m_assetManager->LoadMaterial(L"CubeMat");
		//cubeMaterial->SetShader(m_assetManager->GetShader(L"BasicMesh"));
		//cubeMaterial->SetTexture(Graphics::TEXTURE_SLOT_DIFFUSE, m_assetManager->LoadTexture(L"Assets/Textures/Cube.png"));
		//cubeMaterial->SetDiffuseColor(Vector3(1.0f, 1.0f, 1.0f)); // White color
		//cubeMaterial->SetSpecularColor(Vector3(1.0f, 1.0f, 1.0f));
		//cubeMaterial->SetSpecularPower(10.0f);

		//Material* shipMaterial = m_assetManager->LoadMaterial(L"ShipMat");
		//shipMaterial->SetShader(m_assetManager->GetShader(L"BasicMesh"));
		//shipMaterial->SetTexture(Graphics::TEXTURE_SLOT_DIFFUSE, m_assetManager->LoadTexture(L"Assets/Textures/PlayerShip.dds"));
		//shipMaterial->SetDiffuseColor(Vector3(1.0f, 1.0f, 1.0f)); // White color
		//shipMaterial->SetSpecularColor(Vector3(1.0f, 1.0f, 1.0f));
		//shipMaterial->SetSpecularPower(10.0f);
	}

	{
		// LOADING SKELETONS & ANIMATIONS -----------------------------------
		// m_assetManager->LoadSkeleton(L"Assets/Anims/SK_Mannequin.itpskel");
		// m_assetManager->LoadAnimation(L"Assets/Anims/ThirdPersonRun.itpanim2");
	}

	{
		// CREATING LIGHTING ------------------------------------------------
		m_lightingBuffer = pGraphics.CreateGraphicsBuffer(
			&m_lightingConstants,
			sizeof(m_lightingConstants),
			D3D11_BIND_CONSTANT_BUFFER,
			D3D11_CPU_ACCESS_WRITE,
			D3D11_USAGE_DYNAMIC
		);

		/*SetAmbientLight(Vector3(0.1f, 0.1f, 0.1f));

		Lights::PointLightData* light_1 = AllocateLight();
		light_1->lightColor = Vector3(0.0f, 0.0f, 1.0f);
		light_1->position = Vector3(-100.0f, 0.0f, 100.0f);
		light_1->innerRadius = 20.0f;
		light_1->outerRadius = 200.0f;

		Lights::PointLightData* light_2 = AllocateLight();
		light_2->lightColor = Vector3(0.0f, 1.0f, 0.0f);
		light_2->position = Vector3(0.0f, 150.0f, 0.0f);
		light_2->innerRadius = 20.0f;
		light_2->outerRadius = 200.0f;

		Lights::PointLightData* light_3 = AllocateLight();
		light_3->lightColor = Vector3(1.0f, 0.0f, 0.0f);
		light_3->position = Vector3(100.0f, 0.0f, 100.0f);
		light_3->innerRadius = 20.0f;
		light_3->outerRadius = 200.0f;*/
	}

	{
		// Creating Blur constants
		m_gaussianBuffer = pGraphics.CreateGraphicsBuffer(
			&m_gaussianConstants,
			sizeof(m_gaussianConstants),
			D3D11_BIND_CONSTANT_BUFFER,
			D3D11_CPU_ACCESS_WRITE,
			D3D11_USAGE_DYNAMIC
		);
	}

	{	
		// create a texture and a matching render target
		m_offscreenTexture = new Texture();
		// full-sized
		m_offScreenRenderTarget = m_offscreenTexture->CreateRenderTarget(pGraphics.GetScreenWidth(),
			pGraphics.GetScreenHeight(), DXGI_FORMAT_R32G32B32A32_FLOAT);

		// weird-sized for down-sampling
		m_halfSizedTexture = new Texture();
		m_halfSizedTarget = m_halfSizedTexture->CreateRenderTarget(pGraphics.GetScreenWidth() / 2.0f,
			pGraphics.GetScreenHeight() / 2.0f, DXGI_FORMAT_R32G32B32A32_FLOAT);

		m_quarterSizedTexture_A = new Texture();
		m_quarterSizedTarget_A = m_quarterSizedTexture_A->CreateRenderTarget(pGraphics.GetScreenWidth() / 4.0f,
			pGraphics.GetScreenHeight() / 4.0f, DXGI_FORMAT_R32G32B32A32_FLOAT);

		m_quarterSizedTexture_B = new Texture();
		m_quarterSizedTarget_B = m_quarterSizedTexture_B->CreateRenderTarget(pGraphics.GetScreenWidth() / 4.0f,
			pGraphics.GetScreenHeight() / 4.0f, DXGI_FORMAT_R32G32B32A32_FLOAT);
	}

	{
		// CREATING GAME OBJECTS and CAMERA ---------------------------------
		// 
		// No more triangles :(
		// Creating a triangle render object


		// triagMesh = new Mesh(new VertexBuffer(vert, ARRAY_SIZE(vert), sizeof(vert[0]), indices, ARRAY_SIZE(indices), sizeof(indices[0])),
		// m_assetManager->LoadMaterial(L"TriagMat"));
		// RenderObj* m_triangle = new RenderObj(triagMesh)

		// RenderObj* m_ship = new RenderObj(m_assetManager->LoadMesh(L"Assets/Meshes/PlayerShip.itpmesh3"));

		// m_renderObjects.push_back(m_triangle);
		// m_renderObjects.push_back(m_ship);

		m_camera = new Camera();
		m_physics = new Physics();

		m_opaqueBlend = pGraphics.CreateBlendState(false, D3D11_BLEND_SRC_COLOR, D3D11_BLEND_DEST_COLOR);
		m_additiveBlend = pGraphics.CreateBlendState(true, D3D11_BLEND_ONE, D3D11_BLEND_ONE);

		LoadLevel(L"Assets/Levels/Level10.itplevel");

		JobManager::Get()->Begin();

	}
}

void Game::Shutdown()
{
	// Deleting render objects
	for (int i = 0; i < m_renderObjects.size(); i++)
	{
		delete m_renderObjects[i];
	}
	delete triagMesh;

	m_lightingBuffer->Release();
	m_gaussianBuffer->Release();
	m_offScreenRenderTarget->Release();
	m_halfSizedTarget->Release();
	m_quarterSizedTarget_A->Release();
	m_quarterSizedTarget_B->Release();

	m_opaqueBlend->Release();
	m_additiveBlend->Release();

	delete m_quadBuffer;
	delete m_camera;
	delete m_physics;
	
	delete m_offscreenTexture;
	delete m_halfSizedTexture;
	delete m_quarterSizedTexture_A;
	delete m_quarterSizedTexture_B;

	JobManager::Get()->End();

	m_assetManager->Clear();

	pGraphics.CleanD3D();
}

void Game::Update(float deltaTime)
{
	// g_rotationAngle += Math::Pi * deltaTime;
	// g_rotationAngle = 1.0f; // for verification

	/*m_renderObjects[0]->m_perObjectConstants.c_modelToWorld = Matrix4::CreateScale(2.0f)
		* Matrix4::CreateRotationY(g_rotationAngle)
		* Matrix4::CreateRotationX(0.25f * g_rotationAngle);*/
	PROFILE_SCOPE(game_update);

	for (auto obj : m_renderObjects)
	{
		obj->Update(deltaTime);
	}

	JobManager::Get()->WaitForJobs();
}

void Game::RenderFrame()
{
	PROFILE_SCOPE(game_renderFrame);

	// Set the render target
	// pGraphics.SetRenderTarget(pGraphics.GetBackBuffer(), pGraphics.GetDepthStencilView());

	// Now, we are WRITING to OFFSCREEN_RENDER_TARGET
	pGraphics.SetRenderTarget(m_offScreenRenderTarget, pGraphics.GetDepthStencilView());
	pGraphics.SetBlendState(m_opaqueBlend);
	{	
		// Clear the screen to blue
		Graphics::Color4 clearColor(0.0f, 0.2f, 0.4f, 1.0f);
		pGraphics.ClearRenderTarget(clearColor);
		pGraphics.ClearDepthBuffer(pGraphics.GetDepthStencilView(), 1.0f);
	}

	{   // Activating camera
		m_camera->SetActive();
	}

	{
		// Activating lighting
		pGraphics.UploadBuffer(m_lightingBuffer, &m_lightingConstants, sizeof(m_lightingConstants));
		pGraphics.GetDeviceContext()->PSSetConstantBuffers(
			Graphics::CONSTANT_BUFFER_LIGHTING,
			1,
			&m_lightingBuffer
		);
	}

	{   
		// Drawing items
		for (int i = 0; i < m_renderObjects.size(); i++)
		{
			m_renderObjects[i]->Draw();
		}
	}
	
	// Doing a chain of render target swaps to downsample
	// To reset texture
	pGraphics.SetActiveTexture(0, nullptr);

	{
		// First, use BloomMask to draw onto the Half-by-half
		pGraphics.SetRenderTarget(m_halfSizedTarget, nullptr);
		m_offscreenTexture->SetActive(0);
		m_assetManager->GetShader(L"BloomMask")->SetActive();
		pGraphics.SetViewport(0.0f, 0.0f, 400.0f, 300.0f);
		m_quadBuffer->Draw(m_quadBuffer->GetVertStride());
	}

	// To reset texture
	pGraphics.SetActiveTexture(0, nullptr);

	{
		// They copy onto the quarter-by-quarter buffer 
		pGraphics.SetRenderTarget(m_quarterSizedTarget_A, nullptr);
		m_halfSizedTexture->SetActive(0);
		m_assetManager->GetShader(L"Copy")->SetActive();
		pGraphics.SetViewport(0.0f, 0.0f, 200.0f, 150.0f);
		m_quadBuffer->Draw(m_quadBuffer->GetVertStride());
	}

	// To reset texture
	pGraphics.SetActiveTexture(0, nullptr);

	{
		// Bluring horizontal
		pGraphics.SetRenderTarget(m_quarterSizedTarget_B, nullptr);
		m_quarterSizedTexture_A->SetActive(0);
		// Passing in constants
		m_gaussianConstants.c_isHorizontal = true;
		m_gaussianConstants.c_textureSize = Vector2(200.0f, 150.0f);
		pGraphics.UploadBuffer(m_gaussianBuffer, &m_gaussianConstants, sizeof(m_gaussianConstants));
		pGraphics.GetDeviceContext()->PSSetConstantBuffers(
			Graphics::CONSTANT_BUFFER_GAUSSIAN,
			1,
			&m_gaussianBuffer
		);
		m_assetManager->GetShader(L"Blur")->SetActive();
		pGraphics.SetViewport(0.0f, 0.0f, 200.0f, 150.0f);
		m_quadBuffer->Draw(m_quadBuffer->GetVertStride());
	}

	// To reset texture
	pGraphics.SetActiveTexture(0, nullptr);

	{
		// Bluring vertical
		pGraphics.SetRenderTarget(m_quarterSizedTarget_A, nullptr);
		m_quarterSizedTexture_B->SetActive(0);
		// Passing in constants
		m_gaussianConstants.c_isHorizontal = false;
		pGraphics.UploadBuffer(m_gaussianBuffer, &m_gaussianConstants, sizeof(m_gaussianConstants));
		pGraphics.GetDeviceContext()->PSSetConstantBuffers(
			Graphics::CONSTANT_BUFFER_GAUSSIAN,
			1,
			&m_gaussianBuffer
		);
		m_assetManager->GetShader(L"Blur")->SetActive();
		pGraphics.SetViewport(0.0f, 0.0f, 200.0f, 150.0f);
		m_quadBuffer->Draw(m_quadBuffer->GetVertStride());
	}

	// To reset texture
	pGraphics.SetActiveTexture(0, nullptr);

	{
		pGraphics.SetBlendState(m_additiveBlend);
		// Finally BLEND!!!
		pGraphics.SetRenderTarget(m_offScreenRenderTarget, nullptr);
		m_quarterSizedTexture_A->SetActive(0);
		m_assetManager->GetShader(L"Copy")->SetActive();
		pGraphics.SetViewport(0.0f, 0.0f, 800.0f, 600.0f);
		m_quadBuffer->Draw(m_quadBuffer->GetVertStride());
	}

	// To reset texture
	pGraphics.SetActiveTexture(0, nullptr);

	{
		pGraphics.SetBlendState(m_opaqueBlend);
		pGraphics.SetRenderTarget(pGraphics.GetBackBuffer(), nullptr);
		m_offscreenTexture->SetActive(0);
		m_assetManager->GetShader(L"Copy")->SetActive();
		m_quadBuffer->Draw(m_quadBuffer->GetVertStride());
	}

	// To reset texture
	pGraphics.SetActiveTexture(0, nullptr);

	pGraphics.EndFrame();
}

void Game::OnKeyDown(uint32_t key)
{
	m_keyIsHeld[key] = true;
}

void Game::OnKeyUp(uint32_t key)
{
	m_keyIsHeld[key] = false;
}

bool Game::IsKeyHeld(uint32_t key) const
{
	const auto find = m_keyIsHeld.find(key);
	if (find != m_keyIsHeld.end())
		return find->second;
	return false;
}

Lights::PointLightData* Game::AllocateLight()
{
	for (int i = 0; i < Lights::MAX_POINT_LIGHTS; i++)
	{
		if (!m_lightingConstants.c_pointLight[i].isEnabled)
		{
			m_lightingConstants.c_pointLight[i].isEnabled = true;
			return &m_lightingConstants.c_pointLight[i];
		}
	}
	return nullptr;
}

void Game::FreeLight(Lights::PointLightData* pLight)
{
	pLight->isEnabled = false;
}

void Game::SetAmbientLight(const Vector3& color)
{
	m_lightingConstants.c_ambiant = color;
}

const Vector3& Game::GetAmbientLight() const
{
	return m_lightingConstants.c_ambiant;
}

AssetManager* Game::GetAssetManager()
{
	return m_assetManager;
}

bool Game::LoadLevel(const WCHAR* fileName)
{
	std::ifstream file(fileName);
	if (!file.is_open())
	{
		return false;
	}

	std::stringstream fileStream;
	fileStream << file.rdbuf();
	std::string contents = fileStream.str();
	rapidjson::StringStream jsonStr(contents.c_str());
	rapidjson::Document doc;
	doc.ParseStream(jsonStr);

	if (!doc.IsObject())
	{
		return false;
	}

	std::string str = doc["metadata"]["type"].GetString();
	int ver = doc["metadata"]["version"].GetInt();

	// Check the metadata
	if (!doc["metadata"].IsObject() ||
		str != "itplevel" ||
		ver != 2)
	{
		return false;
	}

	// Getting camera data
	Vector3 camPosition;
	bool camPosOk = GetVectorFromJSON(doc["camera"], "position", camPosition);

	Quaternion camRotation;
	bool camRotOk = GetQuaternionFromJSON(doc["camera"], "rotation", camRotation);

	if (!camPosOk || !camRotOk)
	{
		DbgAssert(false, "Level File Invalid Camera Data");
		return false;
	}

	Matrix4 camTranslationMatrix = Matrix4::CreateTranslation(camPosition);
	Matrix4 camRotationMatrix = Matrix4::CreateFromQuaternion(camRotation);
	Matrix4 cameraToWorld = camRotationMatrix * camTranslationMatrix;
	Matrix4 projMatrix =
		Matrix4::CreateRotationY(-Math::PiOver2) *
		Matrix4::CreateRotationZ(-Math::PiOver2) *
		Matrix4::CreatePerspectiveFOV(
			Math::ToRadians(70.0f),
			pGraphics.GetScreenWidth(),
			pGraphics.GetScreenHeight(),
			25.0f, 10000.0f);

	Matrix4 worldToCamera = cameraToWorld;
	worldToCamera.Invert();

	m_camera->m_perCameraConstants.c_viewProj = worldToCamera * projMatrix;
	m_camera->m_perCameraConstants.c_cameraPosition = camPosition;


	// Setting Ambient Light Data
	Vector3 ambientLightColor;
	bool lightOk = GetVectorFromJSON(doc["lightingData"], "ambient", ambientLightColor);

	if (!lightOk)
	{
		DbgAssert(false, "Level File Invalid Lighting Data");
		return false;
	}
	SetAmbientLight(ambientLightColor);

	// Read the renderObjects format
	const rapidjson::Value& renderObjFormat = doc["renderObjects"];
	if (!renderObjFormat.IsArray() || renderObjFormat.Size() < 1)
	{
		DbgAssert(false, "Level File Invalid renderObject Format");
		return false;
	}

	for (rapidjson::SizeType i = 0; i < renderObjFormat.Size(); i++)
	{
		if (!renderObjFormat[i].IsObject())
		{
			DbgAssert(false, "Level File Invalid renderObject Format");
			return false;
		}
		// Getting data
		Vector3 pos;
		bool posOk = GetVectorFromJSON(renderObjFormat[i], "position", pos);
		Quaternion rot;
		bool rotOk = GetQuaternionFromJSON(renderObjFormat[i], "rotation", rot);
		float scale;
		bool scaleOk = GetFloatFromJSON(renderObjFormat[i], "scale", scale);
		std::wstring meshLoc;
		bool meshOk = GetWStringFromJSON(renderObjFormat[i], "mesh", meshLoc);

		if (!posOk || !rotOk || !scaleOk || !meshOk)
		{
			DbgAssert(false, "Level File Invalid renderObject Data");
			return false;
		}

		Matrix4 objMatrix = Matrix4::CreateScale(scale) * Matrix4::CreateFromQuaternion(rot) * Matrix4::CreateTranslation(pos);
		Mesh* objMesh = m_assetManager->LoadMesh(meshLoc);
		RenderObj* obj = nullptr;

		// Checking if mesh is skinned or not
		if (objMesh->IsSkinned())
		{
			obj = new SkinnedObj(objMesh);
		}
		else
		{
			obj = new RenderObj(objMesh);
		}

		obj->m_perObjectConstants.c_modelToWorld = objMatrix;
		m_renderObjects.push_back(obj);

		// Going through the component array
		const rapidjson::Value& componentFormat = renderObjFormat[i]["components"];
		if (!componentFormat.IsArray())
		{
			DbgAssert(false, "Level File Invalid Component Format");
			return false;
		}

		for (rapidjson::SizeType i = 0; i < componentFormat.Size(); i++)
		{
			std::string type;
			bool typeOk = GetStringFromJSON(componentFormat[i], "type", type);
			if (!typeOk)
			{
				DbgAssert(false, "Level File Invalid Component Data");
				return false;
			}
			if (type == "PointLight")
			{
				PointLight* pointLight = new PointLight(this, obj);
				pointLight->LoadProperties(componentFormat[i]);
				obj->AddComponent(pointLight);
			}
			else if (type == "Character")
			{
				Character* myCharacter = new Character(this, static_cast<SkinnedObj*>(obj));
				myCharacter->LoadProperties(componentFormat[i]);
				obj->AddComponent(myCharacter);
			}
			else if (type == "Player")
			{
				Player* myPlayer = new Player(static_cast<SkinnedObj*>(obj), this);
				myPlayer->LoadProperties(componentFormat[i]);
				obj->AddComponent(myPlayer);
			}
			else if (type == "FollowCam")
			{
				FollowCam* myFollowCam = new FollowCam(obj, this);
				myFollowCam->LoadProperties(componentFormat[i]);
				obj->AddComponent(myFollowCam);
			}
			else if (type == "CollisionBox")
			{
				CollisionBox* myCollisionBox = new CollisionBox(obj, this);
				myCollisionBox->LoadProperties(componentFormat[i]);
				obj->AddComponent(myCollisionBox);
			}
			else if (type == "SimpleRotate")
			{
				SimpleRotate* myRotate = new SimpleRotate(this, obj);
				myRotate->LoadProperties(componentFormat[i]);
				obj->AddComponent(myRotate);
			}
		}
	}

	return true;
}