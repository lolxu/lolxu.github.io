#include "stdafx.h"
#include "SimpleRotate.h"
#include "game.h"
#include "RenderObj.h"
#include "engineMath.h"
#include <cmath>

SimpleRotate::SimpleRotate(Game* game, RenderObj* pObj) : Component(pObj)
{
	m_game = game;
	m_renderObj = pObj;
}

SimpleRotate::~SimpleRotate()
{
}

void SimpleRotate::Update(float deltaTime)
{
	// rotating
	m_angle += m_speed * deltaTime;
	Matrix4 curModelToWorld = m_renderObj->m_perObjectConstants.c_modelToWorld;
	m_renderObj->m_perObjectConstants.c_modelToWorld = Matrix4::CreateScale(curModelToWorld.GetScale().x) * Matrix4::CreateRotationZ(m_angle);
}

void SimpleRotate::LoadProperties(const rapidjson::Value& properties)
{
	bool speedOk = GetFloatFromJSON(properties, "speed", m_speed);

	if (!speedOk)
	{
		DbgAssert(false, "Level File Invalid Simple Rotate Format");
		return;
	}
}
