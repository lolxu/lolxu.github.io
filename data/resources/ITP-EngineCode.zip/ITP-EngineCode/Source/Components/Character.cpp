#include "stdafx.h"
#include "Character.h"
#include "RenderObj.h"
#include "SkinnedObj.h"
#include "game.h"
#include "assetManager.h"
#include "stringUtil.h"
#include "Job.h"
#include "AnimJob.h"
#include "JobManager.h"
#include <Profiler.h>

Character::Character(Game* game, SkinnedObj* pObj) : Component(pObj)
{
	m_game = game;
	m_skinnedObj = pObj;
}

Character::~Character()
{
}

void Character::LoadProperties(const rapidjson::Value& properties)
{
	std::wstring skeletonLoc;
	bool skeletonOk = GetWStringFromJSON(properties, "skeleton", skeletonLoc);

	if (!skeletonOk)
	{
		DbgAssert(false, "Level File Invalid Character Format");
		return;
	}

	// Loading skeleton
	m_skeleton = m_game->GetAssetManager()->LoadSkeleton(skeletonLoc);

	// Loading animations
	const rapidjson::Value& animations = properties["animations"];
	if (!animations.IsArray())
	{
		DbgAssert(false, "Level File Invalid Character Format");
		return;
	}
	for (rapidjson::SizeType i = 0; i < animations.Size(); i++)
	{
		std::string animName = animations[i][0].GetString();
		std::string tempLoc = animations[i][1].GetString();
		std::wstring animLoc;
		StringUtil::String2WString(animLoc, tempLoc);
		Animation* anim = m_game->GetAssetManager()->LoadAnimation(animLoc);

		// Storing in the map
		m_animTable[animName] = anim;
		/*if (i == 1)
		{
			m_curAnim = anim;
		}*/
	}

	// std::vector<Matrix4> outPoses(m_skeleton->GetNumBones(), Matrix4::Identity);
	// m_curAnim->GetGlobalPoseAtTime(outPoses, m_skeleton, 0.0f);
}

bool Character::SetAnim(const std::string& animName)
{
	if (m_animTable.find(animName) != m_animTable.end())
	{
		m_curAnim = m_animTable[animName];
		m_curAnimTime = 0.0f;
		return true;
	}
	return false;
}

void Character::UpdateAnim(float deltaTime)
{
	PROFILE_SCOPE(update_anim);

	// Wrapping the animation time
	m_curAnimTime += deltaTime;

	while (m_curAnimTime > m_curAnim->GetLength())
	{
		float delta = m_curAnimTime - m_curAnim->GetLength();
		m_curAnimTime = delta;
	}

	AnimJob* newJob = new AnimJob(m_skeleton, m_curAnim, m_skinnedObj, m_curAnimTime);
	JobManager::Get()->AddJob(newJob);

	// Calculating anim poses - no multi-threading
	//std::vector<Matrix4> outPoses(m_skeleton->GetNumBones(), Matrix4::Identity);
	//m_curAnim->GetGlobalPoseAtTime(outPoses, m_skeleton, m_curAnimTime);
	//std::vector<Matrix4> invBindPoses = m_skeleton->GetGlobalInvBindPoses();

	//for (int i = 0; i < outPoses.size(); i++)
	//{
	//	m_skinnedObj->m_skinConstants.c_skinMatrix[i] = invBindPoses[i] * outPoses[i];
	//}
}

void Character::Update(float deltaTime)
{
	if (!m_curAnim)
	{
		SetAnim("run");
	}
	UpdateAnim(deltaTime);
}
