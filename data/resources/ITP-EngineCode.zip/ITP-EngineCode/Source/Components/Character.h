#pragma once
#include "Component.h"
class Character : public Component
{
public:
	Character(class Game* game, class SkinnedObj* pObj);
	~Character();
	virtual void LoadProperties(const rapidjson::Value& properties) override;
	bool SetAnim(const std::string& animName);
	void UpdateAnim(float deltaTime);
	virtual void Update(float deltaTime) override;

protected:
	class Game* m_game;
	class SkinnedObj* m_skinnedObj;
	class Skeleton* m_skeleton;
	std::unordered_map<std::string, const class Animation*> m_animTable;
	const class Animation* m_curAnim;
	float m_curAnimTime = 0.0f;
};

