#include "stdafx.h"
#include "Components/PointLight.h"
#include "game.h"
#include "RenderObj.h"

PointLight::PointLight(Game* game, RenderObj* pObj) : Component(pObj)
{
	m_game = game;
	m_lightData = m_game->AllocateLight();
}

PointLight::~PointLight()
{
	m_game->FreeLight(m_lightData);
}

void PointLight::LoadProperties(const rapidjson::Value& properties)
{
	Vector3 lightColor;
	bool colorOk = GetVectorFromJSON(properties, "lightColor", lightColor);
	float innerRad;
	bool innerOk = GetFloatFromJSON(properties, "innerRadius", innerRad);
	float outerRad;
	bool outerOk = GetFloatFromJSON(properties, "outerRadius", outerRad);

	if (!colorOk || !innerOk || !outerOk)
	{
		DbgAssert(false, "Level File Invalid Point Light Format");
		return;
	}

	m_lightData->lightColor = lightColor;
	m_lightData->innerRadius = innerRad;
	m_lightData->outerRadius = outerRad;
}

void PointLight::Update(float deltaTime)
{
	m_lightData->position = m_renderObj->m_perObjectConstants.c_modelToWorld.GetTranslation();
}


