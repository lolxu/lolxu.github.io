#pragma once
#include "Component.h"
#include "Lights.h"
class PointLight :
	public Component
{
public:
	PointLight(class Game* game, class RenderObj* pObj);
	~PointLight();

	virtual void LoadProperties(const rapidjson::Value& properties) override;
	virtual void Update(float deltaTime) override;

private:
	class Game* m_game;
	Lights::PointLightData* m_lightData;
};

