#pragma once
#include "Component.h"
class SimpleRotate : public Component
{
public:
	SimpleRotate(class Game* game, class RenderObj* pObj);
	~SimpleRotate();

	virtual void Update(float deltaTime) override;
	virtual void LoadProperties(const rapidjson::Value& properties) override;
private:
	class Game* m_game;
	class RenderObj* m_renderObj;
	float m_speed = 0.0f;
	float m_angle = 0.0f;
};

