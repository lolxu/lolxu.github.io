#include "stdafx.h"
#include "Skeleton.h"
#include <fstream>
#include <sstream>
#include "jsonUtil.h"

Skeleton::Skeleton()
{
}

Skeleton::~Skeleton()
{
}

size_t Skeleton::GetNumBones() const
{
	return m_bones.size();
}

const Skeleton::Bone& Skeleton::GetBone(size_t idx) const
{
	return m_bones[idx];
}

const std::vector<Skeleton::Bone>& Skeleton::GetBones() const
{
	return m_bones;
}

const std::vector<Matrix4>& Skeleton::GetGlobalInvBindPoses() const
{
	return m_inverseBindPoses;
}

Skeleton* Skeleton::StaticLoad(const WCHAR* fileName, AssetManager* pAssetManager)
{
	Skeleton* pSkel = new Skeleton();
	if (false == pSkel->Load(fileName))
	{
		delete pSkel;
		return nullptr;
	}
	return pSkel;
}

bool Skeleton::Load(const WCHAR* fileName)
{
	std::ifstream file(fileName);
	if (!file.is_open())
	{
		return false;
	}

	// Loading json style
	std::stringstream fileStream;
	fileStream << file.rdbuf();
	std::string contents = fileStream.str();
	rapidjson::StringStream jsonStr(contents.c_str());
	rapidjson::Document doc;
	doc.ParseStream(jsonStr);

	if (!doc.IsObject())
	{
		DbgAssert(false, "Unable to open Skeleton file");
		return false;
	}

	// Metadata and version load
	std::string str = doc["metadata"]["type"].GetString();
	int ver = doc["metadata"]["version"].GetInt();

	// Check the metadata
	if (!doc["metadata"].IsObject() ||
		str != "itpskel" ||
		ver != 1)
	{
		DbgAssert(false, "Skeleton File Incorrect Version");
		return false;
	}

	int boneCount;
	bool boneCountOk = GetIntFromJSON(doc, "bonecount", boneCount);

	// Load in the bones
	const rapidjson::Value& boneJson = doc["bones"];
	if (!boneJson.IsArray() || boneJson.Size() < 1)
	{
		DbgAssert(false, "Skeleton File Invalid Bone Format");
		return false;
	}
	// Load each bone
	for (rapidjson::SizeType i = 0; i < boneJson.Size(); i++)
	{
		const rapidjson::Value& bone = boneJson[i];
		if (!bone.IsObject())
		{
			DbgAssert(false, "Skeleton File Invalid Bone Format");
			return false;
		}

		// Getting bone name and parent
		std::string boneName;
		bool boneNameOk = GetStringFromJSON(bone, "name", boneName);
		int boneParent;
		bool boneParentOk = GetIntFromJSON(bone, "parent", boneParent);
		// getting bindpose
		const rapidjson::Value& bindPose = bone["bindpose"];
		if (!bindPose.IsObject())
		{
			DbgAssert(false, "Skeleton File Invalid BindPose Format");
			return false;
		}
		// Bind pose rotation
		Quaternion bindPoseRot;
		bool bindPoseRotOk = GetQuaternionFromJSON(bindPose, "rot", bindPoseRot);
		// Bind pose translation
		Vector3 bindPoseTrans;
		bool bindPoseTransOk = GetVectorFromJSON(bindPose, "trans", bindPoseTrans);

		if (!boneNameOk || !boneParentOk || !bindPoseRotOk || !bindPoseTransOk)
		{
			DbgAssert(false, "Skeleton File Invalid Bone Format");
			return false;
		}

		// Otherwise we add the bone
		Bone newBone;
		newBone.boneName = boneName;
		newBone.boneTransform.m_rotation = bindPoseRot;
		newBone.boneTransform.m_translation = bindPoseTrans;
		newBone.pIndex = boneParent;
		m_bones.push_back(newBone);
	}
	ComputeGlobalInvBindPose();
	return true;
}

void Skeleton::ComputeGlobalInvBindPose()
{
	// First loop - compute the bind poses for every bone (Not inverted yet)
	for (auto bone : m_bones)
	{
		Matrix4 bindPose = bone.boneTransform.ToMatrix();
		if (bone.pIndex != -1)
		{
			// Going up the parents
			bindPose = bindPose * m_inverseBindPoses[bone.pIndex];
		}
		m_inverseBindPoses.push_back(bindPose);
	}

	// Second loop - Loop through the invert the bind poses
	// DO NOT use auto here and changing the element
	// auto is a copy of the element, NOT a reference!!!!
	for (int i = 0; i < m_inverseBindPoses.size(); i++)
	{
		m_inverseBindPoses[i].Invert();
	}
}
