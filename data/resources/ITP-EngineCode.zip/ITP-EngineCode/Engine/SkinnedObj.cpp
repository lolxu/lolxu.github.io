#include "stdafx.h"
#include "SkinnedObj.h"
#include "Graphics.h"

SkinnedObj::SkinnedObj(const Mesh* mesh) : RenderObj(mesh)
{
	for (int i = 0; i < MAX_SKELETON_BONES; i++)
	{
		m_skinConstants.c_skinMatrix[i] = Matrix4::Identity;
	}

	m_skinBuffer = Graphics::Get()->CreateGraphicsBuffer(
		&m_skinConstants,
		sizeof(m_skinConstants),
		D3D11_BIND_CONSTANT_BUFFER,
		D3D11_CPU_ACCESS_WRITE,
		D3D11_USAGE_DYNAMIC
	);
}

SkinnedObj::~SkinnedObj()
{
	m_skinBuffer->Release();
}

void SkinnedObj::Draw()
{
	Graphics::Get()->UploadBuffer(m_skinBuffer, &m_skinConstants, sizeof(m_skinConstants));
	Graphics::Get()->GetDeviceContext()->VSSetConstantBuffers(Graphics::ConstantBuffer::CONSTANT_BUFFER_SKINNEDOBJ, 1, &m_skinBuffer);
	RenderObj::Draw();
}
