#include "stdafx.h"
#include "RenderObj.h"
#include "VertexBuffer.h"
#include <Graphics.h>
#include "Material.h"
#include <VertexFormat.h>
#include "mesh.h"
#include "Component.h"

RenderObj::RenderObj(const Mesh* mesh)
{
	m_mesh = mesh;

	m_objectBuffer = Graphics::Get()->CreateGraphicsBuffer(
		&m_perObjectConstants,
		sizeof(m_perObjectConstants),
		D3D11_BIND_CONSTANT_BUFFER,
		D3D11_CPU_ACCESS_WRITE,
		D3D11_USAGE_DYNAMIC
	);
}

RenderObj::~RenderObj()
{
	m_objectBuffer->Release();
}

void RenderObj::Draw()
{
	// update your object buffer with your current matrix and upload that to the GPU
	Graphics::Get()->UploadBuffer(m_objectBuffer, &m_perObjectConstants, sizeof(m_perObjectConstants));
	Graphics::Get()->GetDeviceContext()->VSSetConstantBuffers(Graphics::ConstantBuffer::CONSTANT_BUFFER_RENDEROBJ, 1, &m_objectBuffer);
	m_mesh->Draw();
}

void RenderObj::AddComponent(Component* pComp)
{
	m_components.push_back(pComp);
}

void RenderObj::Update(float deltaTime)
{
	for (auto comp : m_components)
	{
		comp->Update(deltaTime);
	}
}
