#pragma once
#include "assetCache.h"
#include "Shader.h"
#include "texture.h"
#include "Material.h"
#include "mesh.h"
#include "Skeleton.h"
#include "Animation.h"

class AssetManager
{
public:
	AssetManager();
	~AssetManager();

	void Clear();

	// Get and set shaders
	Shader* GetShader(const std::wstring& shaderName);
	void SetShader(const std::wstring& shaderName, Shader* pShader);

	// Loading textures
	Texture* LoadTexture(const std::wstring& fileName);

	// Loading materials
	Material* LoadMaterial(const std::wstring& materialName);

	// Loading meshes
	Mesh* LoadMesh(const std::wstring& fileName);

	// Loading skeleton
	Skeleton* LoadSkeleton(const std::wstring& fileName);

	// Loading animations
	Animation* LoadAnimation(const std::wstring& fileName);

private:
	AssetCache<Shader>* m_shaderCache;
	AssetCache<Texture>* m_textureCache;
	AssetCache<Material>* m_materialCache;
	AssetCache<Mesh>* m_meshCache;
	AssetCache<Skeleton>* m_skeletonCache;
	AssetCache<Animation>* m_animationCache;
};

