#pragma once
#include "engineMath.h"

class Physics
{
public:
	class AABB
	{
	public:
		AABB(Vector3 minCorner, Vector3 maxCorner);
		~AABB();
		Vector3 m_minCorner;
		Vector3 m_maxCorner;
	};
	class LineSegment
	{
	public:
		LineSegment(Vector3 startPoint, Vector3 endPoint);
		~LineSegment();
		Vector3 m_startPoint;
		Vector3 m_endPoint;
	};
	static bool Intersect(const AABB& a, const AABB& b, AABB* pOverlap = nullptr);
	static bool Intersect(const LineSegment& segment, const AABB& box, Vector3* pHitPoint = nullptr);
	static bool UnitTest();

	void AddObj(const class CollisionBox* pObj);
	void RemoveObj(const class CollisionBox* pObj);

	bool RayCast(const LineSegment& segment, Vector3* pHitPoint = nullptr);

	class RenderObj* RayCastHitObject(const LineSegment& segment, Vector3* pHitPoint = nullptr);


private:
	std::vector<const class CollisionBox*> m_collisionBoxes;
};

