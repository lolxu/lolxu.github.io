#pragma once

#include "BoneTransform.h"
#include "engineMath.h"

class Animation
{
public:
	Animation();
	~Animation();
	uint32_t GetNuimBones() const { return m_numBones; }
	uint32_t GetNumFrames() const { return m_numFrames; }
	float GetLength() const { return m_animLength; }

	static Animation* StaticLoad(const WCHAR* fileName, class AssetManager* pAssetManager);
	bool Load(const WCHAR* fileName);

	void GetGlobalPoseAtTime(std::vector<Matrix4>& outPoses, const class Skeleton* inSkeleton, float inTime) const;

private:
	uint32_t m_numBones;
	uint32_t m_numFrames;
	float m_animLength;
	std::vector<std::vector<BoneTransform>> m_animData;
};

