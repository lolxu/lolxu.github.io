#pragma once
#include <atomic>
#include <mutex>
#include <queue>

class JobManager
{
public:
	JobManager();
	~JobManager();

	// For multi-threading static access
	std::atomic<bool> m_shutdownSignal;
	std::atomic<int> m_jobCounter;
	static JobManager* Get() { static JobManager instance; return &instance; }

	void Begin();
	void End();
	void AddJob(class Job* pJob);
	void WaitForJobs();

	class Job* PullJob();

private:
	std::vector<class Worker*> m_workers;
	std::queue<class Job*> m_jobs;
	std::mutex m_jobLock;
};

