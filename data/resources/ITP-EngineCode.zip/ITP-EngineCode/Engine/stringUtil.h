#pragma once
#include <string>

namespace StringUtil
{
    void String2WString(std::wstring &output, const std::string &input);
}
