#include "stdafx.h"
#include "assetManager.h"

AssetManager::AssetManager()
{
	m_shaderCache = new AssetCache<Shader>(this);
	m_textureCache = new AssetCache<Texture>(this);
	m_materialCache = new AssetCache<Material>(this);
	m_meshCache = new AssetCache<Mesh>(this);
	m_skeletonCache = new AssetCache<Skeleton>(this);
	m_animationCache = new AssetCache<Animation>(this);
}

AssetManager::~AssetManager()
{
}

void AssetManager::Clear()
{
	m_shaderCache->Clear();
	m_textureCache->Clear();
	m_materialCache->Clear();
	m_meshCache->Clear();
	m_skeletonCache->Clear();
	m_animationCache->Clear();
}

Shader* AssetManager::GetShader(const std::wstring& shaderName)
{
	return m_shaderCache->Get(shaderName);
}

void AssetManager::SetShader(const std::wstring& shaderName, Shader* pShader)
{
	m_shaderCache->Cache(shaderName, pShader);
}

Texture* AssetManager::LoadTexture(const std::wstring& fileName)
{
	return m_textureCache->Load(fileName);
}

Material* AssetManager::LoadMaterial(const std::wstring& materialName)
{
	return m_materialCache->Load(materialName);
}

Mesh* AssetManager::LoadMesh(const std::wstring& fileName)
{
	return m_meshCache->Load(fileName);
}

Skeleton* AssetManager::LoadSkeleton(const std::wstring& fileName)
{
	return m_skeletonCache->Load(fileName);
}

Animation* AssetManager::LoadAnimation(const std::wstring& fileName)
{
	return m_animationCache->Load(fileName);
}
