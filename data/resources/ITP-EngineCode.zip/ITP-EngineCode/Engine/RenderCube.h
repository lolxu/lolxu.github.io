#pragma once

#include "RenderObj.h"

class RenderCube : public RenderObj
{
public:
	RenderCube(class Material* material);
	~RenderCube();
};

