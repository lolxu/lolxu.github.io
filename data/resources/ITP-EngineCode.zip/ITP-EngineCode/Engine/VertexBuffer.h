#pragma once
class VertexBuffer
{
public:
	VertexBuffer(const void* vertData, uint32_t vertCount, uint32_t vertStride, const void* indexData, uint32_t indexCount, uint32_t indexStride);
	~VertexBuffer();

	UINT GetVertStride() const { return m_vertStride; }
	UINT GetIndexCount() const { return m_indexCount; }

	void Draw(UINT vertSize) const;

private:
	// D3D11buffers
	ID3D11Buffer* m_buffer;
	ID3D11Buffer* m_indexBuffer;
	DXGI_FORMAT m_indexBufferFormat;

	const void* m_vertData;
	UINT m_vertStride;
	UINT m_indexCount;
	class Graphics* pGraphics;
};

