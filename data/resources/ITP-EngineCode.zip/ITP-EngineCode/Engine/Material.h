#pragma once

#include "engineMath.h"
#include "Graphics.h"
#include <d3d11.h>

class Material
{
public:

	struct MaterialConstants
	{
		Vector3 c_diffuseColor;
		float padding_1;
		Vector3 c_specularColor;
		float c_specularPower;
	} m_materialConstants;

	Material();
	~Material();
	void SetActive();
	void SetShader(const class Shader* shader);
	void SetTexture(int slot, const class Texture* texture);
	void SetDiffuseColor(const Vector3& color);
	void SetSpecularColor(const Vector3& color);
	void SetSpecularPower(float power);

	// Loading using asset manager
	static Material* StaticLoad(const WCHAR* fileName, class AssetManager* pManager);

	bool Load(const WCHAR* fileName, AssetManager* pAssetManager);

private:
	class Graphics* pGraphics;

	ID3D11Buffer* m_materialBuffer;
	const class Shader* m_shader;
	const class Texture* m_textures[Graphics::TEXTURE_SLOT_TOTAL];

};

