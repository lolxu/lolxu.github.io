#include "stdafx.h"
#include "BoneTransform.h"
#include "engineMath.h"

Matrix4 BoneTransform::ToMatrix() const
{
	return Matrix4::CreateFromQuaternion(m_rotation) * Matrix4::CreateTranslation(m_translation);
}

BoneTransform BoneTransform::Interpolate(const BoneTransform& a, const BoneTransform& b, float f)
{
	Vector3 vecCompA = a.m_translation;
	Vector3 vecCompB = b.m_translation;
	Quaternion quatCompA = a.m_rotation;
	Quaternion quatCompB = b.m_rotation;

	Vector3 lerpedVec = Lerp(vecCompA, vecCompB, f);
	Quaternion slerpedQuat = Slerp(quatCompA, quatCompB, f);

	BoneTransform lerpedBoneTransform;
	lerpedBoneTransform.m_translation = lerpedVec;
	lerpedBoneTransform.m_rotation = slerpedQuat;

	return lerpedBoneTransform;
}
