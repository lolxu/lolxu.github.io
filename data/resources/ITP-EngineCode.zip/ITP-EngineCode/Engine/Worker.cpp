#include "stdafx.h"
#include "Worker.h"
#include "JobManager.h"
#include "Job.h"

void Worker::Begin()
{
	if (!JobManager::Get()->m_shutdownSignal)
	{
		m_thread = std::thread(Loop);
	}
}

void Worker::End()
{
	if (m_thread.joinable())
	{
		m_thread.join();
	}
}

void Worker::Loop()
{
	while (!JobManager::Get()->m_shutdownSignal)
	{
		Job* currentJob = JobManager::Get()->PullJob();
		if (currentJob) 
		{
			currentJob->DoIt();
			JobManager::Get()->m_jobCounter--;
			delete currentJob;
		}
	}
	return;
}
