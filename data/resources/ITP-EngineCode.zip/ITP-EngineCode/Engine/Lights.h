#pragma once

#include "engineMath.h"

namespace Lights
{
	const int MAX_POINT_LIGHTS = 8;

	struct PointLightData {
		Vector3 lightColor;
		float padding_1;
		Vector3 position;
		float innerRadius;
		float outerRadius;
		bool isEnabled;

		char padding_2;
		short padding_3;
		float padding_4;
		float padding_5;
	};

	struct LightingConstants
	{
		Vector3 c_ambiant;
		float padding;
		PointLightData c_pointLight[MAX_POINT_LIGHTS]; // maximum is defined as 8...
	};

	class Lights
	{
	public:

	};
}



