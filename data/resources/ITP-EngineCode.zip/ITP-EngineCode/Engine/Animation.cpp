#include "Animation.h"
#include "stdafx.h"
#include "Animation.h"
#include "assetManager.h"
#include "jsonUtil.h"
#include "sstream"
#include "fstream"

Animation::Animation()
{
}

Animation::~Animation()
{
}

Animation* Animation::StaticLoad(const WCHAR* fileName, AssetManager* pAssetManager)
{
	Animation* pAnim = new Animation();
	if (false == pAnim->Load(fileName))
	{
		delete pAnim;
		return nullptr;
	}
	return pAnim;
}

bool Animation::Load(const WCHAR* fileName)
{
	std::ifstream file(fileName);
	if (!file.is_open())
	{
		return false;
	}

	// Loading json style
	std::stringstream fileStream;
	fileStream << file.rdbuf();
	std::string contents = fileStream.str();
	rapidjson::StringStream jsonStr(contents.c_str());
	rapidjson::Document doc;
	doc.ParseStream(jsonStr);

	if (!doc.IsObject())
	{
		DbgAssert(false, "Unable to open Skeleton file");
		return false;
	}

	// Metadata and version load
	std::string str = doc["metadata"]["type"].GetString();
	int ver = doc["metadata"]["version"].GetInt();

	// Check the metadata
	if (!doc["metadata"].IsObject() ||
		str != "itpanim" ||
		ver != 2)
	{
		DbgAssert(false, "Animation File Incorrect Version");
		return false;
	}

	const rapidjson::Value& sequenceJson = doc["sequence"];
	if (!sequenceJson.IsObject())
	{
		DbgAssert(false, "Animation File Incorrect Sequence Format");
		return false;
	}

	// Loading #frames, #bones, animation length
	int frames;
	bool framesOk = GetIntFromJSON(sequenceJson, "frames", frames);
	float length;
	bool lengthOk = GetFloatFromJSON(sequenceJson, "length", length);
	int boneCount;
	bool boneCountOk = GetIntFromJSON(sequenceJson, "bonecount", boneCount);

	if (!framesOk || !lengthOk || !boneCountOk)
	{
		DbgAssert(false, "Animation File Incorrect Sequence Data");
		return false;
	}

	// Setting member data
	m_numFrames = frames;
	m_numBones = boneCount;
	m_animLength = length;
	m_animData = std::vector<std::vector<BoneTransform>>(m_numBones, std::vector<BoneTransform>());

	// Loading all tracks
	const rapidjson::Value& tracksData = sequenceJson["tracks"];
	if (!tracksData.IsArray())
	{
		DbgAssert(false, "Animation File Incorrect Tracks Data");
		return false;
	}
	for (rapidjson::SizeType i = 0; i < tracksData.Size(); i++)
	{
		const rapidjson::Value& track = tracksData[i];
		if (!track.IsObject())
		{
			DbgAssert(false, "Animation File Incorrect Tracks Data");
			return false;
		}
		int boneIdx;
		bool boneIdxOk = GetIntFromJSON(track, "bone", boneIdx);
		if (!boneIdxOk)
		{
			DbgAssert(false, "Animation File Incorrect Tracks Data");
			return false;
		}

		// Going through transforms array
		const rapidjson::Value& transforms = track["transforms"];
		if (!transforms.IsArray())
		{
			DbgAssert(false, "Animation File Incorrect Tracks Data");
			return false;
		}
		for (rapidjson::SizeType j = 0; j < transforms.Size(); j++)
		{
			Quaternion rot;
			bool rotOk = GetQuaternionFromJSON(transforms[j], "rot", rot);
			Vector3 trans;
			bool transOk = GetVectorFromJSON(transforms[j], "trans", trans);
			if (!rotOk || !transOk)
			{
				DbgAssert(false, "Animation File Incorrect Tracks Data");
				return false;
			}

			// Creating a keyframe and pushing it to the animData with corresponding bone
			BoneTransform keyFrame;
			keyFrame.m_rotation = rot;
			keyFrame.m_translation = trans;

			m_animData[boneIdx].push_back(keyFrame);
		}
	}

	return true;
}

void Animation::GetGlobalPoseAtTime(std::vector<Matrix4>& outPoses, const Skeleton* inSkeleton, float inTime) const
{
	std::vector<Skeleton::Bone> bones = inSkeleton->GetBones();
	for (int i = 0; i < bones.size(); i++)
	{
		Skeleton::Bone curBone = bones[i];
		if (m_animData[i].size() != 0)
		{
			// Calculating closest frame
			float timePerFrame = m_animLength / (m_numFrames - 1);
			int closestFrame = (int)(inTime / timePerFrame) + 1;
			int lastFrame = ((closestFrame - 1) + m_numFrames) % m_numFrames;

			// Trying to smooth out the animations
			float fVal = (inTime - timePerFrame * lastFrame) / timePerFrame;
			Matrix4 pose = BoneTransform::Interpolate(m_animData[i][lastFrame], m_animData[i][closestFrame], fVal).ToMatrix();

			// Combine with parent's matrix if there is one
			if (curBone.pIndex != -1)
			{
				pose = pose * outPoses[curBone.pIndex];
			}

			outPoses[i] = pose;
		}
		else
		{
			outPoses[i] = Matrix4::Identity;
		}
	}
}
