#pragma once
#include <unordered_map>

#define PROFILE_SCOPE(name) \
Profiler::ScopedTimer name##_scope(Profiler::Get()->GetTimer(std::string(#name)))

class Profiler
{
private:
	Profiler();
	~Profiler();

	FILE* jsonStream;

public:
	static Profiler* Get() { static Profiler instance; return &instance; };
	void BeginTimer(const std::string& name, uint64_t startTime);
	void EndTimer(uint64_t endTime);

	friend class Timer;

	class Timer {
	private:
		Timer(std::string name);
		~Timer();

		std::string m_name;
		double m_currentFrameTime;
		double m_longestFrameTime;
		double m_totalFrameTime;
		int m_capturedFrameCount;
		std::chrono::high_resolution_clock::time_point m_startTime;

	public:

		void Start();
		void Stop();
		void Reset();
		const std::string& GetName() const { return m_name; }
		double GetTime_ms() const { return m_currentFrameTime; }
		double GetMax_ms() const { return m_longestFrameTime; }
		double GetAvg_ms() const { return m_totalFrameTime / m_capturedFrameCount; }

		friend class Profiler;
	};

	class ScopedTimer {
	public:
		ScopedTimer(Timer* timer);
		~ScopedTimer();

	private:
		Timer* m_timer;
	};

// Stuff that deals with timer
private:
	std::unordered_map<std::string, Timer*> m_timers;

public:
	Timer* GetTimer(const std::string& name);
	void ResetAll();
};

