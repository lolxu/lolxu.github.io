#pragma once

#include "engineMath.h"

class Camera
{
public:
	Camera();
	virtual ~Camera();

	struct PerCameraConstants
	{
		Matrix4 c_viewProj;
		Vector3 c_cameraPosition;
		int temp;
	} m_perCameraConstants;

	Matrix4 m_worldToCameraMatrix;
	Matrix4 m_projMatrix;

	void SetActive();

protected:

	ID3D11Buffer* m_cameraBuffer;
	class Graphics* pGraphics;
};

