#include "stdafx.h"
#include "CollisionBox.h"
#include "RenderObj.h"
#include "../Source/game.h"

CollisionBox::CollisionBox(RenderObj* pObj, Game* pGame) 
	: Component(pObj), m_AABB(Vector3::Zero, Vector3::One)
{
	m_game = pGame;
	m_pObj = pObj;
	m_game->GetPhysics()->AddObj(this);
}

CollisionBox::~CollisionBox()
{
	m_game->GetPhysics()->RemoveObj(this);
}

void CollisionBox::LoadProperties(const rapidjson::Value& properties)
{
	GetVectorFromJSON(properties, "min", m_AABB.m_minCorner);
	GetVectorFromJSON(properties, "max", m_AABB.m_maxCorner);
}

Physics::AABB CollisionBox::GetAABB() const
{
	// Scaling
	float scaleFactor = m_renderObj->m_perObjectConstants.c_modelToWorld.GetScale().x;
	Vector3 center = (m_AABB.m_maxCorner + m_AABB.m_minCorner) / 2.0f;
	Vector3 halfExtent = (m_AABB.m_maxCorner - m_AABB.m_minCorner) / 2.0f;
	halfExtent *= scaleFactor;

	Physics::AABB copyAABB = m_AABB;
	copyAABB.m_maxCorner = center + halfExtent;
	copyAABB.m_minCorner = center - halfExtent;
	
	// Translation
	Vector3 translation = m_renderObj->m_perObjectConstants.c_modelToWorld.GetTranslation();
	Vector3 translateDirection = translation - center;
	copyAABB.m_maxCorner += translateDirection;
	copyAABB.m_minCorner += translateDirection;

	return copyAABB;
}

RenderObj* CollisionBox::GetParentObject() const
{
	return m_pObj;
}
