#pragma once
#include <thread>
#include <atomic>

class Worker
{
public:
	void Begin();
	void End();
	static void Loop();

private:
	std::thread m_thread;
};

