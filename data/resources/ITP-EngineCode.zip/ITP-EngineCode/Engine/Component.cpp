#include "stdafx.h"
#include "Component.h"
#include "RenderObj.h"

Component::Component(RenderObj* pObj)
{
	m_renderObj = pObj;
}

Component::~Component()
{
}

void Component::LoadProperties(const rapidjson::Value& properties)
{
}

void Component::Update(float deltaTime)
{
}
