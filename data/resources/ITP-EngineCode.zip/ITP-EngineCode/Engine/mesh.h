#pragma once

#include "engineMath.h"
#include "Graphics.h"

class AssetManager;
class Material;
class VertexBuffer;

class Mesh
{
public:
	Mesh(const VertexBuffer* pVertexBuffer, Material* material);
	~Mesh();

	void Draw() const;

	bool Load(const WCHAR* fileName, AssetManager* pAssetManager);
	static Mesh* StaticLoad(const WCHAR* fileName, AssetManager* pAssetManager);

	bool IsSkinned() const { return m_isSkinned; };

protected:
	Material* m_material;
	const VertexBuffer* m_vertexBuffer;
	bool m_isSkinned;
};