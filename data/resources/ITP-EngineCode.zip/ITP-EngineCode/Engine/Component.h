#include "jsonUtil.h"

#pragma once
class Component
{
public:
	Component(class RenderObj* pObj);
	virtual ~Component();
	virtual void LoadProperties(const rapidjson::Value& properties);
	virtual void Update(float deltaTime);

protected:
	class RenderObj* m_renderObj;

};

