#pragma once
#include "Job.h"
class AnimJob : public Job
{
public:
	AnimJob(class Skeleton* pSkel, const class Animation* pAnim, class SkinnedObj* pSkinObj, float pCurTime);

protected:
	virtual void DoIt() override;

private:
	class SkinnedObj* m_skinnedObj;
	class Skeleton* m_skeleton;
	const class Animation* m_curAnim;
	float m_curAnimTime;
};

