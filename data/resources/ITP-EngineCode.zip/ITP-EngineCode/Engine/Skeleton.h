#pragma once

#include "BoneTransform.h"

class Skeleton
{
public:
	struct Bone {
		BoneTransform boneTransform;
		std::string boneName;
		int pIndex;
	};
	Skeleton();
	~Skeleton();

	size_t GetNumBones() const;
	const Bone& GetBone(size_t idx) const;
	const std::vector<Bone>& GetBones() const;
	const std::vector<Matrix4>& GetGlobalInvBindPoses() const;

	static Skeleton* StaticLoad(const WCHAR* fileName, class AssetManager* pAssetManager);
	bool Load(const WCHAR* fileName);

private:
	std::vector<Bone> m_bones;
	std::vector<Matrix4> m_inverseBindPoses;

	void ComputeGlobalInvBindPose();
};

