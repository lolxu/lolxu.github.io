#pragma once
#include "RenderObj.h"

#define MAX_SKELETON_BONES 80

class SkinnedObj : public RenderObj
{
public:
	SkinnedObj(const Mesh* mesh);
	~SkinnedObj();

	struct SkinConstants
	{
		Matrix4 c_skinMatrix[MAX_SKELETON_BONES];
	} m_skinConstants;

	virtual void Draw() override;

private:
	ID3D11Buffer* m_skinBuffer;
};

