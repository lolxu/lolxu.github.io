#pragma once

#include "engineMath.h"

class RenderObj
{
public:
	RenderObj(const class Mesh* mesh);
	virtual ~RenderObj();
	virtual void Draw();

	void AddComponent(class Component* pComp);
	virtual void Update(float deltaTime);


	struct PerObjectConstants {
		Matrix4 c_modelToWorld;
	} m_perObjectConstants;

protected:
	ID3D11Buffer* m_objectBuffer;

	const class Mesh* m_mesh;

private:
	std::vector<class Component*> m_components;
};

