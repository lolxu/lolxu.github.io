#include "stdafx.h"
#include "Material.h"
#include "texture.h"
#include "Shader.h"
#include "assetManager.h"
#include <fstream>
#include <sstream>
#include "rapidjson\include\rapidjson\rapidjson.h"
#include "rapidjson\include\rapidjson\document.h"
#include "jsonUtil.h"
#include "utility"

Material::Material()
{
	pGraphics = Graphics::Get();
	m_shader = nullptr;
	m_materialBuffer = pGraphics->CreateGraphicsBuffer(
		&m_materialConstants,
		sizeof(m_materialConstants),
		D3D11_BIND_CONSTANT_BUFFER,
		D3D11_CPU_ACCESS_WRITE,
		D3D11_USAGE_DYNAMIC
	);
}

Material::~Material()
{
	m_materialBuffer->Release();
}

void Material::SetActive()
{
	if (m_shader)
	{
		m_shader->SetActive();
	}
	else
	{
		DbgAssert(false, "Failed to load shader...");
	}


	// Loop through all textures to set each one active
	for (int i = 0; i < Graphics::TEXTURE_SLOT_TOTAL; i++)
	{
		if (m_textures[i] != nullptr)
		{
			m_textures[i]->SetActive(i);
		}
	}
	pGraphics->UploadBuffer(m_materialBuffer, &m_materialConstants, sizeof(m_materialConstants));
	pGraphics->GetDeviceContext()->PSSetConstantBuffers(
		Graphics::CONSTANT_BUFFER_MATERIAL,
		1,
		&m_materialBuffer
	);
}

void Material::SetShader(const Shader* shader)
{
	m_shader = shader;
}

void Material::SetTexture(int slot, const Texture* texture)
{
	m_textures[slot] = texture;
}

void Material::SetDiffuseColor(const Vector3& color)
{
	m_materialConstants.c_diffuseColor = color;
}

void Material::SetSpecularColor(const Vector3& color)
{
	m_materialConstants.c_specularColor = color;
}

void Material::SetSpecularPower(float power)
{
	m_materialConstants.c_specularPower = power;
}

Material* Material::StaticLoad(const WCHAR* fileName, AssetManager* pManager)
{
	Material* pMat = new Material();

	// We are still creating a new material and returning it if load fails
	if (false == pMat->Load(fileName, pManager))
	{
		delete pMat;
		return new Material();
	}
	return pMat;
}

bool Material::Load(const WCHAR* fileName, AssetManager* pAssetManager)
{
	// Load from file
	std::ifstream file(fileName);
	if (!file.is_open())
	{
		return false;
	}

	// Loading json style
	std::stringstream fileStream;
	fileStream << file.rdbuf();
	std::string contents = fileStream.str();
	rapidjson::StringStream jsonStr(contents.c_str());
	rapidjson::Document doc;
	doc.ParseStream(jsonStr);

	if (!doc.IsObject())
	{
		DbgAssert(false, "Unable to open Mesh file");
		return false;
	}

	// Metadata and version load
	std::string str = doc["metadata"]["type"].GetString();
	int ver = doc["metadata"]["version"].GetInt();

	// Check the metadata
	if (!doc["metadata"].IsObject() ||
		str != "itpmat" ||
		ver != 1)
	{
		DbgAssert(false, "Material File Incorrect Version");
		return false;
	}

	// Read shader
	std::wstring shaderName;
	GetWStringFromJSON(doc, "shader", shaderName);
	SetShader(pAssetManager->GetShader(shaderName));

	// Read textures (an array)
	const rapidjson::Value& textures = doc["textures"];
	if (!textures.IsArray() || textures.Size() < 1)
	{
		DbgAssert(false, "Material File Invalid Textures Format");
		return false;
	}

	for (rapidjson::SizeType i = 0; i < textures.Size(); i++)
	{
		if (!textures[i].IsString())
		{
			DbgAssert(false, "Material File Invalid Textures Format");
			return false;
		}
		std::string textureName = textures[i].GetString();
		std::wstring textureString(textureName.begin(), textureName.end());
		// Setting diffuse texture and normal map texture
		if (i == 0)
		{
			SetTexture(Graphics::TEXTURE_SLOT_DIFFUSE, pAssetManager->LoadTexture(textureString));
		}
		else
		{
			SetTexture(Graphics::TEXTURE_SLOT_NORMAL, pAssetManager->LoadTexture(textureString));
		}
		
	}

	// Read diffuse, speculars
	Vector3 diffuseColor;
	GetVectorFromJSON(doc, "diffuseColor", diffuseColor);
	SetDiffuseColor(diffuseColor);

	Vector3 specularColor;
	GetVectorFromJSON(doc, "specularColor", specularColor);
	SetSpecularColor(specularColor);

	float specularPower;
	GetFloatFromJSON(doc, "specularPower", specularPower);
	SetSpecularPower(specularPower);

	return true;
}
