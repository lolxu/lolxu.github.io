#pragma once
class Job
{
public:
	// Pure virtual function for DoIt()
	virtual void DoIt() = 0;
};

