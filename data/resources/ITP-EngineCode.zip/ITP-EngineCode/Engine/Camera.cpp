#include "stdafx.h"
#include "Camera.h"
#include <Graphics.h>

Camera::Camera()
{
	// Initializing all the necessary data
	m_worldToCameraMatrix = Matrix4::CreateTranslation(Vector3(500.0f, 0.0f, 0.0f));

	pGraphics = Graphics::Get();

	m_projMatrix =
		Matrix4::CreateRotationY(-Math::PiOver2) *
		Matrix4::CreateRotationZ(-Math::PiOver2) *
		Matrix4::CreatePerspectiveFOV(
			Math::ToRadians(70.0f),
			pGraphics->GetScreenWidth(),
			pGraphics->GetScreenHeight(),
			25.0f, 10000.0f);

	m_perCameraConstants.c_viewProj = m_worldToCameraMatrix * m_projMatrix;

	// Getting the inverse of world-to-camera to get camera position from its translation
	Matrix4 inverseWorldToCamera = m_worldToCameraMatrix;
	inverseWorldToCamera.Invert();
	m_perCameraConstants.c_cameraPosition = inverseWorldToCamera.GetTranslation();

	// ByteWidth must be a multiple of 16 bytes...
	m_cameraBuffer = pGraphics->CreateGraphicsBuffer(
		&m_perCameraConstants,
		sizeof(m_perCameraConstants),
		D3D11_BIND_CONSTANT_BUFFER,
		D3D11_CPU_ACCESS_WRITE,
		D3D11_USAGE_DYNAMIC
	);
}

Camera::~Camera()
{
	m_cameraBuffer->Release();
}

void Camera::SetActive()
{
	// Re-calculate constants
	m_perCameraConstants.c_viewProj = m_worldToCameraMatrix * m_projMatrix;
	Matrix4 inverseWorldToCamera = m_worldToCameraMatrix;
	inverseWorldToCamera.Invert();
	m_perCameraConstants.c_cameraPosition = inverseWorldToCamera.GetTranslation();

	// Uploading the buffer for GPU
	pGraphics->UploadBuffer(m_cameraBuffer,
		&m_perCameraConstants,
		sizeof(m_perCameraConstants)
	);
	pGraphics->GetDeviceContext()->VSSetConstantBuffers(
		Graphics::CONSTANT_BUFFER_CAMERA,
		1,
		&m_cameraBuffer
	);

	pGraphics->GetDeviceContext()->PSSetConstantBuffers(
		Graphics::CONSTANT_BUFFER_CAMERA,
		1,
		&m_cameraBuffer
	);
}
