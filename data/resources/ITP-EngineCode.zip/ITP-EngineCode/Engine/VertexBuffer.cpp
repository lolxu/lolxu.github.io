#include "stdafx.h"
#include "VertexBuffer.h"
#include "VertexFormat.h"
#include <Graphics.h>

VertexBuffer::VertexBuffer(const void* vertData, uint32_t vertCount, uint32_t vertStride,
	const void* indexData, uint32_t indexCount, uint32_t indexStride)
{
	pGraphics = Graphics::Get();
	m_buffer = pGraphics->CreateGraphicsBuffer(
		vertData,
		vertCount * vertStride,
		D3D11_BIND_VERTEX_BUFFER,
		D3D11_CPU_ACCESS_WRITE,
		D3D11_USAGE_DYNAMIC
	);
	m_indexCount = indexCount;
	m_vertStride = vertStride;
	m_vertData = vertData;

	// Check index stride to assign format (2 bytes for uint16, 4 bytes for uint32)
	if (indexStride == 2) {
		m_indexBufferFormat = DXGI_FORMAT_R16_UINT;
	}
	else if (indexStride == 4) {
		m_indexBufferFormat = DXGI_FORMAT_R32_UINT;
	}


	m_indexBuffer = pGraphics->CreateGraphicsBuffer(
		indexData,
		indexCount * indexStride,
		D3D11_BIND_INDEX_BUFFER,
		D3D11_CPU_ACCESS_WRITE,
		D3D11_USAGE_DYNAMIC
	);
}

VertexBuffer::~VertexBuffer()
{
	m_buffer->Release();
	m_indexBuffer->Release();
}

void VertexBuffer::Draw(UINT vertSize) const
{
	UINT vertexSize = vertSize;
	UINT pOffset = 0;
	pGraphics->GetDeviceContext()->IASetVertexBuffers(
		0,
		1,
		&m_buffer,
		&vertexSize,
		&pOffset
	);

	pGraphics->GetDeviceContext()->IASetIndexBuffer(
		m_indexBuffer,
		m_indexBufferFormat,
		pOffset
	);

	pGraphics->GetDeviceContext()->DrawIndexed(m_indexCount, 0, 0);
}
