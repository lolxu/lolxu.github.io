#pragma once
#include "Component.h"
#include "Physics.h"

class CollisionBox :
    public Component
{
public:
    CollisionBox(class RenderObj* pObj, class Game* pGame);
    ~CollisionBox();

    virtual void LoadProperties(const rapidjson::Value& properties) override;
    Physics::AABB GetAABB() const;

    class RenderObj* GetParentObject() const;

private:
    Physics::AABB m_AABB;
    class Game* m_game;
    class RenderObj* m_pObj;
};

