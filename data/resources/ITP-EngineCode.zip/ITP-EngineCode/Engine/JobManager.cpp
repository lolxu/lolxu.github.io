#include "stdafx.h"
#include "JobManager.h"
#include "Worker.h"
#include "Job.h"
#include <csignal>
#include <thread>
#include <Profiler.h>

JobManager::JobManager()
{
	m_shutdownSignal = false;
	for (int i = 0; i < 4; i++)
	{
		m_workers.push_back(new Worker());
	}
}

JobManager::~JobManager()
{
	for (size_t i = 0; i < m_workers.size(); i++)
	{
		delete m_workers[i];
	}

	while (!m_jobs.empty())
	{
		delete m_jobs.front();
		m_jobs.pop();
	}
}

void JobManager::Begin()
{
	for (size_t i = 0; i < m_workers.size(); i++)
	{
		m_workers[i]->Begin();
	}
}

void JobManager::End()
{
	m_shutdownSignal = true;
	for (size_t i = 0; i < m_workers.size(); i++)
	{
		m_workers[i]->End();
	}
}

void JobManager::AddJob(Job* pJob)
{
	m_jobs.push(pJob);
	m_jobCounter++;
}

void JobManager::WaitForJobs()
{
	PROFILE_SCOPE(wait_for_job);
	// Wait until we are done with jobs
	while (m_jobCounter > 0)
	{
		std::this_thread::sleep_for(std::chrono::nanoseconds(1));
	}
}

Job* JobManager::PullJob()
{
	m_jobLock.lock();
	if (m_jobs.empty())
	{
		m_jobLock.unlock();
		return nullptr;
	}
	Job* firstJob = m_jobs.front();
	m_jobs.pop();
	m_jobLock.unlock();
	return firstJob;
}
