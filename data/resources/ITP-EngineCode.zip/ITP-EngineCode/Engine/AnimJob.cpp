#include "stdafx.h"
#include "AnimJob.h"
#include <engineMath.h>
#include "Character.h"
#include "Skeleton.h"
#include "Animation.h"
#include "SkinnedObj.h"

AnimJob::AnimJob(Skeleton* pSkel, const Animation* pAnim, SkinnedObj* pSkinObj, float pCurTime) :
	m_skeleton(pSkel),
	m_curAnim(pAnim),
	m_skinnedObj(pSkinObj),
	m_curAnimTime(pCurTime)
{
}

void AnimJob::DoIt()
{
	// Do animation job
	std::vector<Matrix4> outPoses(m_skeleton->GetNumBones(), Matrix4::Identity);
	m_curAnim->GetGlobalPoseAtTime(outPoses, m_skeleton, m_curAnimTime);
	std::vector<Matrix4> invBindPoses = m_skeleton->GetGlobalInvBindPoses();

	for (int i = 0; i < outPoses.size(); i++)
	{
		m_skinnedObj->m_skinConstants.c_skinMatrix[i] = invBindPoses[i] * outPoses[i];
	}
}
