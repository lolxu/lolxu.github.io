#include "stdafx.h"
#include "Profiler.h"
#include <stdio.h>
#include <thread>

Profiler::Profiler()
{
	errno_t err = fopen_s(&jsonStream, "profile.json", "w");
	if (err == 1)
	{
		DbgAssert(false, "Profiler file cannot be opened");
		return;
	}
	fprintf(jsonStream, "[\n");
}

Profiler::~Profiler()
{
	FILE* stream;
	errno_t err = fopen_s(&stream, "profile.txt", "w");
	if (err == 1)
	{
		DbgAssert(false, "Profiler file cannot be opened");
		return;
	}

	fprintf(stream, "name:, avg (ms), max (ms)\n");
	for (auto iter : m_timers)
	{
		Timer* timer = iter.second;
		fprintf(stream, "%s:, %lf, %lf\n", timer->GetName().c_str(), timer->GetAvg_ms(), timer->GetMax_ms());
	}

	fclose(stream);

	// removing last comma with empty {}
	fprintf(jsonStream, "{}\n]\n");
	fclose(jsonStream);
}

void Profiler::BeginTimer(const std::string& name, uint64_t startTime)
{
	fprintf(jsonStream, "{\"name\": \"%s\", \"ph\": \"B\", \"ts\": %llu, \"pid\": 1, \"tid\": %zu},\n", name.c_str(), startTime, std::hash<std::thread::id>{}(std::this_thread::get_id()));
}

void Profiler::EndTimer(uint64_t endTime)
{
	fprintf(jsonStream, "{\"ph\": \"E\", \"ts\": %llu, \"pid\": 1, \"tid\": %zu},\n", endTime, std::hash<std::thread::id>{}(std::this_thread::get_id()));
}

Profiler::Timer* Profiler::GetTimer(const std::string& name)
{
	// Return timer if it exists
	if (m_timers.find(name) != m_timers.end())
	{
		return m_timers[name];
	}
	// Return a new timer if it doesn't exist
	Timer* newTimer = new Timer(name);
	m_timers.insert(std::make_pair(name, newTimer));
	return newTimer;
}

void Profiler::ResetAll()
{
	// Resetting all timers
	for (auto timer : m_timers)
	{
		timer.second->Reset();
	}
}

Profiler::Timer::Timer(std::string name)
{
	m_name = name;
	m_totalFrameTime = 0.0f;
	m_currentFrameTime = 0.0f;
	m_longestFrameTime = 0.0f;
	m_capturedFrameCount = 0;
}

Profiler::Timer::~Timer()
{
}

void Profiler::Timer::Start()
{
	m_startTime = std::chrono::high_resolution_clock::now();
	Profiler::Get()->BeginTimer(m_name, m_startTime.time_since_epoch().count() / 1000); // To microseconds
}

void Profiler::Timer::Stop()
{
	std::chrono::high_resolution_clock::time_point stopTime = std::chrono::high_resolution_clock::now();
	m_currentFrameTime += std::chrono::duration<double, std::milli>(stopTime - m_startTime).count();
	Profiler::Get()->EndTimer(stopTime.time_since_epoch().count() / 1000); // To microseconds
}

void Profiler::Timer::Reset()
{
	m_totalFrameTime += m_currentFrameTime;
	m_capturedFrameCount++;
	m_longestFrameTime = max(m_longestFrameTime, m_currentFrameTime);
	m_currentFrameTime = 0.0f;
}

Profiler::ScopedTimer::ScopedTimer(Timer* timer)
{
	m_timer = timer;
	m_timer->Start();
}

Profiler::ScopedTimer::~ScopedTimer()
{
	m_timer->Stop();
}
