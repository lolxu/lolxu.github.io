#include "stdafx.h"
#include "Physics.h"
#include "engineMath.h"
#include "CollisionBox.h"

bool Physics::Intersect(const AABB& a, const AABB& b, AABB* pOverlap)
{
    if ((a.m_minCorner.x > b.m_maxCorner.x) || (a.m_maxCorner.x < b.m_minCorner.x) ||
        (a.m_minCorner.y > b.m_maxCorner.y) || (a.m_maxCorner.y < b.m_minCorner.y) ||
        (a.m_minCorner.z > b.m_maxCorner.z) || (a.m_maxCorner.z < b.m_minCorner.z))
    {
        return false;
    }
    pOverlap->m_minCorner.x = max(a.m_minCorner.x, b.m_minCorner.x);
    pOverlap->m_minCorner.y = max(a.m_minCorner.y, b.m_minCorner.y);
    pOverlap->m_minCorner.z = max(a.m_minCorner.z, b.m_minCorner.z);

    pOverlap->m_maxCorner.x = min(a.m_maxCorner.x, b.m_maxCorner.x);
    pOverlap->m_maxCorner.y = min(a.m_maxCorner.y, b.m_maxCorner.y);
    pOverlap->m_maxCorner.z = min(a.m_maxCorner.z, b.m_maxCorner.z);

    return true;
}

bool Physics::Intersect(const LineSegment& segment, const AABB& box, Vector3* pHitPoint)
{
    Vector3 startPoint = segment.m_startPoint;
    Vector3 endPoint = segment.m_endPoint;
    Vector3 dir = endPoint - startPoint;
    Vector3 unnormDir = dir;
    dir.Normalize();

    float tmin = -FLT_MAX;
    float tmax = FLT_MAX;

    // Some base case checks
    if (Math::IsZero(dir.x))
    {
        // If ray is parallel to slab or not
        if (startPoint.x < box.m_minCorner.x || startPoint.x > box.m_maxCorner.x)
        {
            return false;
        }
    }
    if (Math::IsZero(dir.y))
    {
        if (startPoint.y < box.m_minCorner.y || startPoint.y > box.m_maxCorner.y)
        {
            return false;
        }
    }
    if (Math::IsZero(dir.z))
    {   
        if (startPoint.z < box.m_minCorner.z || startPoint.z > box.m_maxCorner.z)
        {
            return false;
        }
    }
    
    // Doing collision checks
    {

        // Check all three "slabs"
        float oodx = 1.0f / dir.x;
        float oody = 1.0f / dir.y;
        float oodz = 1.0f / dir.z;

        {   // Processing X-axis
            float t1 = (box.m_minCorner.x - startPoint.x) * oodx;
            float t2 = (box.m_maxCorner.x - startPoint.x) * oodx;

            if (t1 > t2)
            {
                float tmp = t1;
                t1 = t2;
                t2 = tmp;
            }

            tmin = max(tmin, t1);
            tmax = min(tmax, t2);

            if (tmin > tmax)
            {
                return false;
            }
        }

        {   // Processing Y-axis
            float t1 = (box.m_minCorner.y - startPoint.y) * oody;
            float t2 = (box.m_maxCorner.y - startPoint.y) * oody;

            if (t1 > t2)
            {
                float tmp = t1;
                t1 = t2;
                t2 = tmp;
            }

            tmin = max(tmin, t1);
            tmax = min(tmax, t2);

            if (tmin > tmax)
            {
                return false;
            }
        }

        {   // Processing Z-axis
            float t1 = (box.m_minCorner.z - startPoint.z) * oodz;
            float t2 = (box.m_maxCorner.z - startPoint.z) * oodz;

            if (t1 > t2)
            {
                float tmp = t1;
                t1 = t2;
                t2 = tmp;
            }

            tmin = max(tmin, t1);
            tmax = min(tmax, t2);

            if (tmin > tmax)
            {
                return false;
            }
        }
    }

    // If we can't reach intersection with the segment's length
    if (unnormDir.Length() < (dir * tmin).Length())
    {
        return false;
    }

    *pHitPoint = startPoint + dir * tmin;
   
    return true;
}

bool Physics::UnitTest()
{
    // Test Data
    struct TestAABB
    {
        Physics::AABB a;
        Physics::AABB b;
        Physics::AABB overlap;
    };
    const TestAABB testAABB[] =
    {
    {
    Physics::AABB(Vector3(0.0f, 0.0f, 0.0f), Vector3(100.0f, 100.0f, 100.0f)),
    Physics::AABB(Vector3(0.0f, 0.0f, 0.0f), Vector3(10.0f, 10.0f, 10.0f)),
    Physics::AABB(Vector3(0.0f, 0.0f, 0.0f), Vector3(10.0f, 10.0f, 10.0f))
    },
    {
    Physics::AABB(Vector3(-100.0f, -100.0f, -100.0f), Vector3(100.0f, 100.0f, 100.0f)),
    Physics::AABB(Vector3(-110.0f, -10.0f, -10.0f), Vector3(-90.0f, 10.0f, 10.0f)),
    Physics::AABB(Vector3(-100.0f, -10.0f, -10.0f), Vector3(-90.0f, 10.0f, 10.0f))
    },
    {
    Physics::AABB(Vector3(-100.0f, -100.0f, -100.0f), Vector3(100.0f, 100.0f, 100.0f)),
    Physics::AABB(Vector3(90.0f, -10.0f, -10.0f), Vector3(110.0f, 10.0f, 10.0f)),
    Physics::AABB(Vector3(90.0f, -10.0f, -10.0f), Vector3(100.0f, 10.0f, 10.0f))
    },
    {
    Physics::AABB(Vector3(-100.0f, -100.0f, -100.0f), Vector3(100.0f, 100.0f, 100.0f)),
    Physics::AABB(Vector3(-10.0f, -110.0f, -10.0f), Vector3(10.0f, -90.0f, 10.0f)),
    Physics::AABB(Vector3(-10.0f, -100.0f, -10.0f), Vector3(10.0f, -90.0f, 10.0f))
    },
    {
    Physics::AABB(Vector3(-100.0f, -100.0f, -100.0f), Vector3(100.0f, 100.0f, 100.0f)),
    Physics::AABB(Vector3(-10.0f, 90.0f, -10.0f), Vector3(10.0f, 110.0f, 10.0f)),
    Physics::AABB(Vector3(-10.0f, 90.0f, -10.0f), Vector3(10.0f, 100.0f, 10.0f))
    },
    {
    Physics::AABB(Vector3(-100.0f, -100.0f, -100.0f), Vector3(100.0f, 100.0f, 100.0f)),
    Physics::AABB(Vector3(-10.0f, -10.0f, -110.0f), Vector3(10.0f, 10.0f, -90.0f)),
    Physics::AABB(Vector3(-10.0f, -10.0f, -100.0f), Vector3(10.0f, 10.0f, -90.0f))
    },
    {
    Physics::AABB(Vector3(-100.0f, -100.0f, -100.0f), Vector3(100.0f, 100.0f, 100.0f)),
    Physics::AABB(Vector3(-10.0f, -10.0f, 90.0f), Vector3(10.0f, 10.0f, 110.0f)),
    Physics::AABB(Vector3(-10.0f, -10.0f, 90.0f), Vector3(10.0f, 10.0f, 100.0f))
    },
    {
    Physics::AABB(Vector3(-100.0f, -100.0f, -100.0f), Vector3(100.0f, 100.0f, 100.0f)),
    Physics::AABB(Vector3(-120.0f, -10.0f, -10.0f), Vector3(-110.0f, 10.0f, 10.0f)),
    Physics::AABB(Vector3::One, Vector3::Zero)
    },
    {
    Physics::AABB(Vector3(-100.0f, -100.0f, -100.0f), Vector3(100.0f, 100.0f, 100.0f)),
    Physics::AABB(Vector3(110.0f, -10.0f, -10.0f), Vector3(120.0f, 10.0f, 10.0f)),
    Physics::AABB(Vector3::One, Vector3::Zero)
    },
    {
    Physics::AABB(Vector3(-100.0f, -100.0f, -100.0f), Vector3(100.0f, 100.0f, 100.0f)),
    Physics::AABB(Vector3(-10.0f, -120.0f, -10.0f), Vector3(10.0f, -110.0f, 10.0f)),
    Physics::AABB(Vector3::One, Vector3::Zero)
    },
    {
    Physics::AABB(Vector3(-100.0f, -100.0f, -100.0f), Vector3(100.0f, 100.0f, 100.0f)),
    Physics::AABB(Vector3(-10.0f, 110.0f, -10.0f), Vector3(10.0f, 120.0f, 10.0f)),
    Physics::AABB(Vector3::One, Vector3::Zero)
    },
    {
    Physics::AABB(Vector3(-100.0f, -100.0f, -100.0f), Vector3(100.0f, 100.0f, 100.0f)),
    Physics::AABB(Vector3(-10.0f, -10.0f, -120.0f), Vector3(10.0f, 10.0f, -110.0f)),
    Physics::AABB(Vector3::One, Vector3::Zero)
    },
    {
    Physics::AABB(Vector3(-100.0f, -100.0f, -100.0f), Vector3(100.0f, 100.0f, 100.0f)),
    Physics::AABB(Vector3(-10.0f, -10.0f, 110.0f), Vector3(10.0f, 10.0f, 120.0f)),
    Physics::AABB(Vector3::One, Vector3::Zero)
    },
    };

    for (int i = 0; i < ARRAY_SIZE(testAABB); i++)
    {
        TestAABB curTest = testAABB[i];
        Physics::AABB testResult = curTest.overlap;
        bool isIntersect = Intersect(curTest.a, curTest.b, &curTest.overlap);
        
        Vector3 resultMinCorner = testResult.m_minCorner;
        Vector3 resultMaxCorner = testResult.m_maxCorner;

        Vector3 myMinCorner = curTest.overlap.m_minCorner;
        Vector3 myMaxCorner = curTest.overlap.m_maxCorner;

        if (!Math::IsCloseEnuf(myMinCorner.x, resultMinCorner.x) ||
            !Math::IsCloseEnuf(myMinCorner.y, resultMinCorner.y) ||
            !Math::IsCloseEnuf(myMinCorner.z, resultMinCorner.z) ||
            !Math::IsCloseEnuf(myMaxCorner.x, resultMaxCorner.x) ||
            !Math::IsCloseEnuf(myMaxCorner.y, resultMaxCorner.y) ||
            !Math::IsCloseEnuf(myMaxCorner.z, resultMaxCorner.z) )
        {
            return false;
        }
    }

    // Line segment vs AABB tests
    struct TestSegment
    {
        AABB box;
        LineSegment segment;
        bool hit;
        Vector3 point;
    };
    const TestSegment testSegment[] =
    {
    {
    AABB(Vector3(-100.0f, -100.0f, -100.0f), Vector3(100.0f, 100.0f, 100.0f)),
    LineSegment(Vector3(-110.0f, 0.0f, 0.0f), Vector3(-90.0f, 0.0f, 0.0f)),
    true, Vector3(-100.0f, 0.0f, 0.0f)
    },
    {
    AABB(Vector3(-100.0f, -100.0f, -100.0f), Vector3(100.0f, 100.0f, 100.0f)),
    LineSegment(Vector3(0.0f, -110.0f, 0.0f), Vector3(0.0f, -90.0f, 0.0f)),
    true, Vector3(0.0f, -100.0f, 0.0f)
    },
    {
    AABB(Vector3(-100.0f, -100.0f, -100.0f), Vector3(100.0f, 100.0f, 100.0f)),
    LineSegment(Vector3(0.0f, 0.0f, -110.0f), Vector3(0.0f, 0.0f, -90.0f)),
    true, Vector3(0.0f, 0.0f, -100.0f)
    },
    {
    AABB(Vector3(-100.0f, -100.0f, -100.0f), Vector3(100.0f, 100.0f, 100.0f)),
    LineSegment(Vector3(110.0f, 0.0f, 0.0f), Vector3(90.0f, 0.0f, 0.0f)),
    true, Vector3(100.0f, 0.0f, 0.0f)
    },
    {
    AABB(Vector3(-100.0f, -100.0f, -100.0f), Vector3(100.0f, 100.0f, 100.0f)),
    LineSegment(Vector3(0.0f, 110.0f, 0.0f), Vector3(0.0f, 90.0f, 0.0f)),
    true, Vector3(0.0f, 100.0f, 0.0f)
    },
    {
    AABB(Vector3(-100.0f, -100.0f, -100.0f), Vector3(100.0f, 100.0f, 100.0f)),
    LineSegment(Vector3(0.0f, 0.0f, 110.0f), Vector3(0.0f, 0.0f, 90.0f)),
    true, Vector3(0.0f, 0.0f, 100.0f)
    },
    {
    AABB(Vector3(-100.0f, -100.0f, -100.0f), Vector3(100.0f, 100.0f, 100.0f)),
    LineSegment(Vector3(-120.0f, 0.0f, 0.0f), Vector3(-110.0f, 0.0f, 0.0f)),
    false, Vector3::Zero
    },
    {
    AABB(Vector3(-100.0f, -100.0f, -100.0f), Vector3(100.0f, 100.0f, 100.0f)),
    LineSegment(Vector3(0.0f, -120.0f, 0.0f), Vector3(0.0f, -110.0f, 0.0f)),
    false, Vector3::Zero
    },
    {
    AABB(Vector3(-100.0f, -100.0f, -100.0f), Vector3(100.0f, 100.0f, 100.0f)),
    LineSegment(Vector3(0.0f, 0.0f, -120.0f), Vector3(0.0f, 0.0f, -110.0f)),
    false, Vector3::Zero
    },
    {
    AABB(Vector3(-100.0f, -100.0f, -100.0f), Vector3(100.0f, 100.0f, 100.0f)),
    LineSegment(Vector3(120.0f, 0.0f, 0.0f), Vector3(110.0f, 0.0f, 0.0f)),
    false, Vector3::Zero
    },
    {
    AABB(Vector3(-100.0f, -100.0f, -100.0f), Vector3(100.0f, 100.0f, 100.0f)),
    LineSegment(Vector3(0.0f, 120.0f, 0.0f), Vector3(0.0f, 110.0f, 0.0f)),
    false, Vector3::Zero
    },
    {
    AABB(Vector3(-100.0f, -100.0f, -100.0f), Vector3(100.0f, 100.0f, 100.0f)),
    LineSegment(Vector3(0.0f, 0.0f, 120.0f), Vector3(0.0f, 0.0f, 110.0f)),
    false, Vector3::Zero
    },
    };

    for (int i = 0; i < ARRAY_SIZE(testSegment); i++)
    {
        TestSegment curTest = testSegment[i];
        Vector3 testResult = curTest.point;
        bool isIntersect = Intersect(curTest.segment, curTest.box, &curTest.point);

        if (!Math::IsCloseEnuf(curTest.point.x, testResult.x) ||
            !Math::IsCloseEnuf(curTest.point.y, testResult.y) ||
            !Math::IsCloseEnuf(curTest.point.z, testResult.z) ||
            isIntersect != curTest.hit)
        {
            return false;
        }
    }

    return true;
}

void Physics::AddObj(const CollisionBox* pObj)
{
    m_collisionBoxes.push_back(pObj);
}

void Physics::RemoveObj(const CollisionBox* pObj)
{
    for (size_t i = 0; i < m_collisionBoxes.size(); i++)
    {
        if (m_collisionBoxes[i] == pObj)
        {
            m_collisionBoxes.erase(m_collisionBoxes.begin() + i);
            break;
        }
    }
}

bool Physics::RayCast(const LineSegment& segment, Vector3* pHitPoint)
{
    Vector3 hitResult;
    bool hit = false;

    float minDist = FLT_MAX;
    for (size_t i = 0; i < m_collisionBoxes.size(); i++)
    {
        Physics::AABB curAABB = m_collisionBoxes[i]->GetAABB();
           
        Vector3 curHitPoint;
        bool chkhit = Intersect(segment, curAABB, &curHitPoint);

        if (chkhit)
        {
            Vector3 lineBeginToHit = curHitPoint - segment.m_startPoint;
            if (lineBeginToHit.Length() < minDist)
            {
                minDist = lineBeginToHit.Length();
                hitResult = curHitPoint;
            }
            hit = true;
        }
    }

    *pHitPoint = hitResult;
    return hit;
}

RenderObj* Physics::RayCastHitObject(const LineSegment& segment, Vector3* pHitPoint)
{
    Vector3 hitResult;
    RenderObj* hit = nullptr;

    float minDist = FLT_MAX;
    for (size_t i = 0; i < m_collisionBoxes.size(); i++)
    {
        Physics::AABB curAABB = m_collisionBoxes[i]->GetAABB();

        Vector3 curHitPoint;
        bool chkhit = Intersect(segment, curAABB, &curHitPoint);

        if (chkhit)
        {
            Vector3 lineBeginToHit = curHitPoint - segment.m_startPoint;
            if (lineBeginToHit.Length() < minDist)
            {
                minDist = lineBeginToHit.Length();
                hitResult = curHitPoint;
            }
            hit = m_collisionBoxes[i]->GetParentObject();
        }
    }

    *pHitPoint = hitResult;
    return hit;
}

Physics::AABB::AABB(Vector3 minCorner, Vector3 maxCorner)
{
    m_minCorner = minCorner;
    m_maxCorner = maxCorner;
}

Physics::AABB::~AABB()
{
}

Physics::LineSegment::LineSegment(Vector3 startPoint, Vector3 endPoint)
{
    m_startPoint = startPoint;
    m_endPoint = endPoint;
}

Physics::LineSegment::~LineSegment()
{
}
