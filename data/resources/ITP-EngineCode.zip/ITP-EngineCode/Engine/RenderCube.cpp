#include "stdafx.h"
#include "RenderCube.h"
#include "VertexBuffer.h"
#include "VertexFormat.h"
#include "DbgAssert.h"
#include "mesh.h"
#include "Material.h"
#include <cassert>

RenderCube::RenderCube(Material* material) : RenderObj(nullptr)
{

	// Creating a cube
	VertexPosNormalColorUV cubeVertices[24] = {
		// -Z face

			{ Vector3(-0.5f, 0.5f, -0.5f), Vector3(0.0f, 0.0f, -1.0f), Graphics::Color4(1.0f, 0.0f, 0.0f, 1.0f), Vector2(0.0f, 0.0f)},
			{ Vector3(0.5f, 0.5f, -0.5f), Vector3(0.0f, 0.0f, -1.0f), Graphics::Color4(1.0f, 0.0f, 0.0f, 1.0f), Vector2(1.0f, 0.0f) },
			{ Vector3(0.5f, -0.5f, -0.5f), Vector3(0.0f, 0.0f, -1.0f), Graphics::Color4(1.0f, 0.0f, 0.0f, 1.0f), Vector2(1.0f, 1.0f) },
			{ Vector3(-0.5f, -0.5f, -0.5f), Vector3(0.0f, 0.0f, -1.0f), Graphics::Color4(1.0f, 0.0f, 0.0f, 1.0f), Vector2(0.0f, 1.0f) },

			// +Z face - Green

			{ Vector3(-0.5f, 0.5f, 0.5f), Vector3(0.0f, 0.0f, 1.0f), Graphics::Color4(0.0f, 1.0f, 0.0f, 1.0f), Vector2(0.0f, 0.0f) },
			{ Vector3(0.5f, 0.5f, 0.5f), Vector3(0.0f, 0.0f, 1.0f), Graphics::Color4(0.0f, 1.0f, 0.0f, 1.0f), Vector2(1.0f, 0.0f) },
			{ Vector3(0.5f, -0.5f, 0.5f), Vector3(0.0f, 0.0f, 1.0f), Graphics::Color4(0.0f, 1.0f, 0.0f, 1.0f), Vector2(1.0f, 1.0f) },
			{ Vector3(-0.5f, -0.5f, 0.5f), Vector3(0.0f, 0.0f, 1.0f), Graphics::Color4(0.0f, 1.0f, 0.0f, 1.0f), Vector2(0.0f, 1.0f) },

			// -X face - Blue

			{ Vector3(-0.5f, 0.5f, -0.5f), Vector3(-1.0f, 0.0f, 0.0f), Graphics::Color4(0.0f, 0.0f, 1.0f, 1.0f), Vector2(0.0f, 0.0f) },
			{ Vector3(-0.5f, 0.5f, 0.5f), Vector3(-1.0f, 0.0f, 0.0f), Graphics::Color4(0.0f, 0.0f, 1.0f, 1.0f), Vector2(1.0f, 0.0f) },
			{ Vector3(-0.5f, -0.5f, 0.5f), Vector3(-1.0f, 0.0f, 0.0f), Graphics::Color4(0.0f, 0.0f, 1.0f, 1.0f), Vector2(1.0f, 1.0f) },
			{ Vector3(-0.5f, -0.5f, -0.5f), Vector3(-1.0f, 0.0f, 0.0f), Graphics::Color4(0.0f, 0.0f, 1.0f, 1.0f), Vector2(0.0f, 1.0f) },

			// +X face - Yellow

			{ Vector3(0.5f, 0.5f, -0.5f), Vector3(1.0f, 0.0f, 0.0f), Graphics::Color4(1.0f, 1.0f, 0.0f, 1.0f), Vector2(0.0f, 0.0f) },
			{ Vector3(0.5f, 0.5f, 0.5f), Vector3(1.0f, 0.0f, 0.0f), Graphics::Color4(1.0f, 1.0f, 0.0f, 1.0f), Vector2(1.0f, 0.0f) },
			{ Vector3(0.5f, -0.5f, 0.5f), Vector3(1.0f, 0.0f, 0.0f), Graphics::Color4(1.0f, 1.0f, 0.0f, 1.0f), Vector2(1.0f, 1.0f) },
			{ Vector3(0.5f, -0.5f, -0.5f), Vector3(1.0f, 0.0f, 0.0f), Graphics::Color4(1.0f, 1.0f, 0.0f, 1.0f), Vector2(0.0f, 1.0f) },

			// -Y face - Cyan

			{ Vector3(-0.5f, -0.5f, 0.5f), Vector3(0.0f, -1.0f, 0.0f), Graphics::Color4(0.0f, 1.0f, 1.0f, 1.0f), Vector2(1.0f, 0.0f) },
			{ Vector3(0.5f, -0.5f, 0.5f), Vector3(0.0f, -1.0f, 0.0f), Graphics::Color4(0.0f, 1.0f, 1.0f, 1.0f), Vector2(0.0f, 0.0f) },
			{ Vector3(0.5f, -0.5f, -0.5f), Vector3(0.0f, -1.0f, 0.0f), Graphics::Color4(0.0f, 1.0f, 1.0f, 1.0f), Vector2(0.0f, 1.0f) },
			{ Vector3(-0.5f, -0.5f, -0.5f), Vector3(0.0f, -1.0f, 0.0f), Graphics::Color4(0.0f, 1.0f, 1.0f, 1.0f), Vector2(1.0f, 1.0f) },

			// +Y face - Purple

			{ Vector3(-0.5f, 0.5f, 0.5f), Vector3(0.0f, 1.0f, 0.0f), Graphics::Color4(1.0f, 0.0f, 1.0f, 1.0f), Vector2(0.0f, 1.0f) },
			{ Vector3(0.5f, 0.5f, 0.5f), Vector3(0.0f, 1.0f, 0.0f), Graphics::Color4(1.0f, 0.0f, 1.0f, 1.0f), Vector2(1.0f, 1.0f) },
			{ Vector3(0.5f, 0.5f, -0.5f), Vector3(0.0f, 1.0f, 0.0f), Graphics::Color4(1.0f, 0.0f, 1.0f, 1.0f), Vector2(1.0f, 0.0f) },
			{ Vector3(-0.5f, 0.5f, -0.5f), Vector3(0.0f, 1.0f, 0.0f), Graphics::Color4(1.0f, 0.0f, 1.0f, 1.0f), Vector2(0.0f, 0.0f) }

	};

	uint16_t cubeIndices[36] = {
		// -Z face
		2, 1, 0, 3, 2, 0,
		// +Z face
		4, 5, 6, 4, 6, 7,
		// -X face
		8, 9, 10, 8, 10, 11,
		// +X face
		14, 13, 12, 15, 14, 12,
		// -Y face
		16, 17, 18, 16, 18, 19,
		// +Y face
		22, 21, 20, 23, 22, 20
	};


	uint32_t vertCount = ARRAY_SIZE(cubeVertices);
	uint32_t vertStride = sizeof(cubeVertices[0]);

	uint32_t indexCount = ARRAY_SIZE(cubeIndices);
	uint32_t indexStride = sizeof(cubeIndices[0]);

	// Creating cube's own mesh
	VertexBuffer* vertexBuffer = new VertexBuffer(&cubeVertices, vertCount, vertStride, cubeIndices, indexCount, indexStride);
	m_mesh = new Mesh(vertexBuffer, material);
}

RenderCube::~RenderCube()
{
	delete m_mesh;
}
